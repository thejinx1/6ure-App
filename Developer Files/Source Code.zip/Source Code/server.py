from __future__ import annotations

import atexit
import http.cookiejar
import http.cookies
import html
import json
import hashlib
import email.utils
import mimetypes
import os
import posixpath
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import urllib.parse
import uuid
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import requests

from discord_presence import DiscordPresenceManager, load_presence_config


def resource_root() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


ROOT = resource_root()
APP_ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else ROOT
APP_VERSION = os.environ.get("REYLI_APP_VERSION", "1.2.6")
DATA_ROOT = Path(os.environ.get("REYLI_DATA_DIR", str(ROOT))).expanduser().resolve()
DATA_ROOT.mkdir(parents=True, exist_ok=True)
PORT = int(os.environ.get("PORT", "4173"))
MAX_BODY_BYTES = 2 * 1024 * 1024
CONFIG_FILE_NAME = os.environ.get("REYLI_CONFIG_FILE", "6ure-files-state.json")
CONFIG_BACKUP_FILE_NAME = os.environ.get("REYLI_CONFIG_BACKUP_FILE", "6ure-files-state.backup.json")
CONFIG_TMP_FILE_NAME = os.environ.get("REYLI_CONFIG_TMP_FILE", "6ure-files-state.tmp")
CONFIG_PATH = DATA_ROOT / CONFIG_FILE_NAME
CONFIG_BACKUP_PATH = DATA_ROOT / CONFIG_BACKUP_FILE_NAME
CONFIG_TMP_PATH = DATA_ROOT / CONFIG_TMP_FILE_NAME
PROTECTED_STATIC_NAMES = {CONFIG_PATH.name, CONFIG_BACKUP_PATH.name, CONFIG_TMP_PATH.name}
LEAKER_PROXY_COOKIE_PATH = DATA_ROOT / "leaker-proxy-cookies.lwp"
PROTECTED_STATIC_NAMES.add(LEAKER_PROXY_COOKIE_PATH.name)
UPDATE_CONFIG_FILE_NAME = os.environ.get("REYLI_UPDATE_CONFIG_FILE", "update-config.json")
PROTECTED_STATIC_NAMES.add(UPDATE_CONFIG_FILE_NAME)
DISCORD_PRESENCE_CONFIG_FILE_NAME = os.environ.get(
    "REYLI_DISCORD_PRESENCE_CONFIG_FILE",
    "discord-presence.json",
)
PROTECTED_STATIC_NAMES.add(DISCORD_PRESENCE_CONFIG_FILE_NAME)
UPDATE_DOWNLOAD_DIR = DATA_ROOT / "updates"
UPDATE_BACKUP_DIR = DATA_ROOT / "update-backups"
UPDATE_MAX_PACKAGE_BYTES = int(os.environ.get("REYLI_UPDATE_MAX_PACKAGE_BYTES", str(500 * 1024 * 1024)))
UPDATE_STATE_LOCK = threading.Lock()
UPDATE_STATE = {
    "checking": False,
    "installing": False,
    "lastCheckAt": 0,
    "lastError": "",
    "latest": None,
    "installPhase": "",
    "installMessage": "",
    "downloadedBytes": 0,
    "totalBytes": None,
    "installProgress": 0,
    "installStartedAt": 0,
    "installUpdatedAt": 0,
}
DISCORD_PRESENCE_LOCK = threading.Lock()
DISCORD_PRESENCE: DiscordPresenceManager | None = None
FILES_BASE_URL = "https://files.6ureleaks.com"
FILES_SITE_URL = f"{FILES_BASE_URL}/web/client/files"
DASHBOARD_URL = "https://6ureleaks.com/dashboard"
PROTECTED_LIST_PAGE_URL = "https://6ureleaks.com/requests/protected"
PROTECTED_LIST_API_URL = "https://6ureleaks.com/api/protection/users"
LEAKER_SITE_BASE_URL = "https://6ureleaks.com"
LEAKER_PROXY_PREFIX = "/leaker-proxy"
LEAKER_OAUTH_BRIDGE_PATH = "/leaker-oauth/bridge"
LEAKER_PROXY_TIMEOUT_SECONDS = 45
LEAKER_PROXY_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
)
DISCORD_OAUTH_HOSTS = {"discord.com", "ptb.discord.com", "canary.discord.com", "discordapp.com"}
ALLOWED_EXTERNAL_HOSTS = {"6ureleaks.com", "files.6ureleaks.com", "discord.com"}
NETWORK_CHECK_HOSTS = (
    ("files.6ureleaks.com", 443),
    ("6ureleaks.com", 443),
    ("discord.com", 443),
)
FILES_MIN_ACTION_INTERVAL = float(os.environ.get("REYLI_FILES_MIN_ACTION_INTERVAL", "0.25"))
FILES_TASK_POLL_INTERVAL = float(os.environ.get("REYLI_FILES_TASK_POLL_INTERVAL", "0.35"))
FILES_MAX_UPLOAD_BYTES = 1024 * 1024 * 1024 * 80
FILES_EXTRACT_MAX_ZIP_BYTES = int(os.environ.get("REYLI_FILES_EXTRACT_MAX_ZIP_BYTES", str(FILES_MAX_UPLOAD_BYTES)))
FILES_EXTRACT_MAX_TOTAL_BYTES = int(
    os.environ.get("REYLI_FILES_EXTRACT_MAX_TOTAL_BYTES", str(FILES_MAX_UPLOAD_BYTES))
)
FILES_EXTRACT_MAX_FILES = int(os.environ.get("REYLI_FILES_EXTRACT_MAX_FILES", "250000"))
FILES_UPLOAD_HISTORY_LIMIT = 24
FILES_JOBS: dict[str, "FilesUploadJob"] = {}
FILES_JOBS_LOCK = threading.Lock()
AUTH_LOCK = threading.Lock()
AUTH_STATE = {
    "authenticated": False,
    "username": "",
    "password": "",
}
REMOTE_CLIENT_LOCK = threading.Lock()
REMOTE_CLIENT_TTL_SECONDS = float(os.environ.get("REYLI_REMOTE_CLIENT_TTL_SECONDS", "600"))
REMOTE_CLIENT_CACHE = {
    "username": "",
    "password": "",
    "client": None,
    "expiresAt": 0.0,
}
LEAKER_PROXY_SESSION = requests.Session()
LEAKER_PROXY_LOCK = threading.RLock()
LEAKER_PROXY_SESSION.cookies = http.cookiejar.LWPCookieJar(str(LEAKER_PROXY_COOKIE_PATH))
try:
    if LEAKER_PROXY_COOKIE_PATH.is_file():
        LEAKER_PROXY_SESSION.cookies.load(ignore_discard=True, ignore_expires=True)
except Exception:
    pass
FILES_STATE_STRING_KEYS = {
    "username",
    "password",
    "lastEditor",
    "lastFolderPath",
    "lastFolderName",
}
FILES_STATE_LIST_KEYS = {
    "lastFolderPaths",
    "lastFolderNames",
}
FORM_TOKEN_RE = re.compile(r'name="_form_token"\s+value="([^"]+)"')
CSRF_TOKEN_RE = re.compile(r"'X-CSRF-TOKEN': '([^']+)'")

legacy_root_raw = str(os.environ.get("REYLI_LEGACY_DATA_DIR", "") or "").strip()
LEGACY_DATA_ROOT = Path(legacy_root_raw).expanduser().resolve() if legacy_root_raw else None
if LEGACY_DATA_ROOT == DATA_ROOT:
    LEGACY_DATA_ROOT = None
LEGACY_CONFIG_PATH = LEGACY_DATA_ROOT / CONFIG_FILE_NAME if LEGACY_DATA_ROOT else None
LEGACY_CONFIG_BACKUP_PATH = LEGACY_DATA_ROOT / CONFIG_BACKUP_FILE_NAME if LEGACY_DATA_ROOT else None


def json_bytes(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")


def read_state_file(path: Path | None) -> dict | None:
    if path is None or not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def normalize_string_list(value) -> list[str]:
    if not isinstance(value, list):
        return []

    clean_items: list[str] = []
    seen: set[str] = set()
    for item in value:
        text = str(item or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        clean_items.append(text)
    return clean_items


def sanitize_upload_history(entries) -> list[dict]:
    if not isinstance(entries, list):
        return []

    clean_entries: list[dict] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        editor_name = str(entry.get("editorName", "") or "").strip()
        folder_path = str(entry.get("folderPath", "") or "").strip()
        folder_name = str(entry.get("folderName", "") or "").strip()
        if not editor_name or not folder_path or not folder_name:
            continue

        clean_entry = {
            "editorName": editor_name,
            "folderPath": folder_path,
            "folderName": folder_name,
        }
        saved_at = entry.get("savedAt")
        if isinstance(saved_at, int):
            clean_entry["savedAt"] = saved_at
        clean_entries.append(clean_entry)
        if len(clean_entries) >= FILES_UPLOAD_HISTORY_LIMIT:
            break

    return clean_entries


def sanitize_files_state(raw_files) -> dict:
    clean_files: dict = {}
    if not isinstance(raw_files, dict):
        return clean_files

    for key in FILES_STATE_STRING_KEYS:
        value = raw_files.get(key)
        if isinstance(value, str) and value.strip():
            clean_files[key] = value.strip()

    for key in FILES_STATE_LIST_KEYS:
        items = normalize_string_list(raw_files.get(key))
        if items:
            clean_files[key] = items

    if "lastFolderPaths" not in clean_files and clean_files.get("lastFolderPath"):
        clean_files["lastFolderPaths"] = [clean_files["lastFolderPath"]]
    if "lastFolderNames" not in clean_files and clean_files.get("lastFolderName"):
        clean_files["lastFolderNames"] = [clean_files["lastFolderName"]]

    history = sanitize_upload_history(raw_files.get("recentUploads"))
    if history:
        clean_files["recentUploads"] = history

    return clean_files


def sanitize_persisted_state(payload: dict | None) -> dict:
    raw = payload if isinstance(payload, dict) else {}
    clean = {"files": sanitize_files_state(raw.get("files"))}
    saved_at = raw.get("_savedAt")
    if isinstance(saved_at, int):
        clean["_savedAt"] = saved_at
    return clean


def save_persisted_state(payload: dict) -> dict:
    clean = sanitize_persisted_state(payload)
    clean["_savedAt"] = int(time.time() * 1000)
    text = json.dumps(clean, ensure_ascii=False, indent=2)
    CONFIG_TMP_PATH.write_text(text, encoding="utf-8")
    os.replace(CONFIG_TMP_PATH, CONFIG_PATH)
    CONFIG_BACKUP_PATH.write_text(text, encoding="utf-8")
    return clean


def migrate_legacy_state_if_needed() -> dict | None:
    if CONFIG_PATH.exists() or CONFIG_BACKUP_PATH.exists():
        return None

    for legacy_path in (LEGACY_CONFIG_PATH, LEGACY_CONFIG_BACKUP_PATH):
        legacy_state = read_state_file(legacy_path)
        if legacy_state is None:
            continue
        return save_persisted_state(legacy_state)

    return None


def load_persisted_state() -> dict:
    current = read_state_file(CONFIG_PATH)
    if current is not None:
        return sanitize_persisted_state(current)

    backup = read_state_file(CONFIG_BACKUP_PATH)
    if backup is not None:
        return sanitize_persisted_state(backup)

    migrated = migrate_legacy_state_if_needed()
    if migrated is not None:
        return migrated

    return {"files": {}}


def get_files_state() -> dict:
    files_state = load_persisted_state().get("files", {})
    return dict(files_state) if isinstance(files_state, dict) else {}


def save_files_state(**values) -> dict:
    state = load_persisted_state()
    files_state = state.setdefault("files", {})
    for key, value in values.items():
        if key in FILES_STATE_STRING_KEYS:
            text = str(value or "").strip()
            if text:
                files_state[key] = text
            else:
                files_state.pop(key, None)
            continue

        if key in FILES_STATE_LIST_KEYS:
            items = normalize_string_list(value)
            if items:
                files_state[key] = items
            else:
                files_state.pop(key, None)
    return save_persisted_state(state)


def merge_recent_upload_entries(files_state: dict, entries: list[dict]) -> None:
    current_history = sanitize_upload_history(files_state.get("recentUploads"))
    entry_keys = {
        (entry["editorName"], entry["folderPath"], entry["folderName"])
        for entry in entries
    }
    deduped = [
        item
        for item in current_history
        if (item.get("editorName"), item.get("folderPath"), item.get("folderName")) not in entry_keys
    ]
    files_state["recentUploads"] = [*entries, *deduped][:FILES_UPLOAD_HISTORY_LIMIT]


def record_upload_history(editor_name: str, folder_path: str, folder_name: str) -> dict:
    return record_upload_batch_history(editor_name, [Path(folder_path).expanduser().resolve()])


def record_upload_batch_history(editor_name: str, folder_paths: list[Path]) -> dict:
    state = load_persisted_state()
    files_state = state.setdefault("files", {})
    normalized_editor = str(editor_name or "").strip()
    if not normalized_editor:
        return save_persisted_state(state)

    entries: list[dict] = []
    saved_at = int(time.time() * 1000)
    for folder_path in folder_paths:
        path = Path(folder_path).expanduser().resolve()
        folder_name = path.name.strip()
        folder_text = str(path).strip()
        if not folder_name or not folder_text:
            continue
        entries.append(
            {
                "editorName": normalized_editor,
                "folderPath": folder_text,
                "folderName": folder_name,
                "savedAt": saved_at,
            }
        )

    if not entries:
        return save_persisted_state(state)

    files_state["lastEditor"] = normalized_editor
    files_state["lastFolderPath"] = entries[0]["folderPath"]
    files_state["lastFolderName"] = entries[0]["folderName"]
    files_state["lastFolderPaths"] = [entry["folderPath"] for entry in entries]
    files_state["lastFolderNames"] = [entry["folderName"] for entry in entries]
    merge_recent_upload_entries(files_state, entries)
    return save_persisted_state(state)


def clear_persisted_account_data() -> dict:
    return save_persisted_state({"files": {}})


def clear_last_files_selection() -> dict:
    state = load_persisted_state()
    files_state = state.setdefault("files", {})
    for key in (
        "lastEditor",
        "lastFolderPath",
        "lastFolderName",
        "lastFolderPaths",
        "lastFolderNames",
    ):
        files_state.pop(key, None)
    return save_persisted_state(state)


def sync_session_from_state(state: dict | None = None) -> dict:
    current_state = state if isinstance(state, dict) else load_persisted_state()
    files_state = current_state.get("files", {}) if isinstance(current_state, dict) else {}
    username = str(files_state.get("username", "") or "").strip() if isinstance(files_state, dict) else ""
    password = str(files_state.get("password", "") or "") if isinstance(files_state, dict) else ""
    authenticated = bool(username and password)
    with AUTH_LOCK:
        previous = (
            bool(AUTH_STATE["authenticated"]),
            str(AUTH_STATE["username"]),
            str(AUTH_STATE["password"]),
        )
        AUTH_STATE["authenticated"] = authenticated
        AUTH_STATE["username"] = username if authenticated else ""
        AUTH_STATE["password"] = password if authenticated else ""
    if previous != (authenticated, username if authenticated else "", password if authenticated else ""):
        clear_remote_client_cache()
    return {"authenticated": authenticated, "username": username if authenticated else ""}


def set_session_credentials(username: str, password: str) -> None:
    clean_username = str(username or "").strip()
    clean_password = str(password or "")
    with AUTH_LOCK:
        previous = (
            bool(AUTH_STATE["authenticated"]),
            str(AUTH_STATE["username"]),
            str(AUTH_STATE["password"]),
        )
        AUTH_STATE["authenticated"] = True
        AUTH_STATE["username"] = clean_username
        AUTH_STATE["password"] = clean_password
    if previous != (True, clean_username, clean_password):
        clear_remote_client_cache()


def clear_session_credentials() -> None:
    with AUTH_LOCK:
        previous = bool(AUTH_STATE["authenticated"]) or bool(AUTH_STATE["username"]) or bool(AUTH_STATE["password"])
        AUTH_STATE["authenticated"] = False
        AUTH_STATE["username"] = ""
        AUTH_STATE["password"] = ""
    if previous:
        clear_remote_client_cache()


def get_session_snapshot() -> dict:
    with AUTH_LOCK:
        return {
            "authenticated": bool(AUTH_STATE["authenticated"]),
            "username": str(AUTH_STATE["username"]),
        }


def get_session_credentials() -> tuple[str, str]:
    with AUTH_LOCK:
        if not AUTH_STATE["authenticated"]:
            return "", ""
        return str(AUTH_STATE["username"]), str(AUTH_STATE["password"])


def clear_remote_client_cache() -> None:
    with REMOTE_CLIENT_LOCK:
        client = REMOTE_CLIENT_CACHE.get("client")
        session = getattr(client, "session", None)
        if session is not None:
            try:
                session.close()
            except Exception:
                pass
        REMOTE_CLIENT_CACHE["username"] = ""
        REMOTE_CLIENT_CACHE["password"] = ""
        REMOTE_CLIENT_CACHE["client"] = None
        REMOTE_CLIENT_CACHE["expiresAt"] = 0.0


def quote_remote_path(path: str) -> str:
    return urllib.parse.quote(path, safe="")


def normalize_remote_name(value: str, label: str) -> str:
    cleaned = str(value or "").strip()
    if not cleaned:
        raise ValueError(f"{label} is required.")
    if any(part in cleaned for part in ("/", "\\", "\x00")) or cleaned in {".", ".."}:
        raise ValueError(f"{label} contains invalid characters.")
    return cleaned


def normalize_remote_path(value: str, label: str = "Cloud path", allow_root: bool = True) -> str:
    text = str(value or "").strip().replace("\\", "/")
    if "\x00" in text:
        raise ValueError(f"{label} contains invalid characters.")
    if not text:
        if allow_root:
            return "/"
        raise ValueError(f"{label} is required.")
    if not text.startswith("/"):
        text = "/" + text
    cleaned = posixpath.normpath(text)
    if cleaned in {"", "."}:
        cleaned = "/"
    if not cleaned.startswith("/"):
        cleaned = "/" + cleaned
    if cleaned != "/":
        cleaned = cleaned.rstrip("/")
    if cleaned == "/" and not allow_root:
        raise ValueError(f"{label} cannot be the cloud root.")
    return cleaned


def remote_basename(remote_path: str) -> str:
    return posixpath.basename(normalize_remote_path(remote_path, allow_root=False))


def remote_parent_path(remote_path: str) -> str:
    parent = posixpath.dirname(normalize_remote_path(remote_path, allow_root=False))
    return parent if parent else "/"


def remote_join(parent: str, *parts: str) -> str:
    clean_parent = normalize_remote_path(parent)
    joined = clean_parent
    for part in parts:
        text = str(part or "").strip().replace("\\", "/").strip("/")
        if not text:
            continue
        joined = posixpath.join(joined, text)
    return normalize_remote_path(joined)


def is_remote_dir_type(value) -> bool:
    return str(value or "").strip().lower() in {"1", "dir", "folder", "directory"}


def remote_breadcrumbs(remote_path: str) -> list[dict]:
    clean_path = normalize_remote_path(remote_path)
    crumbs = [{"name": "Cloud", "path": "/"}]
    if clean_path == "/":
        return crumbs

    current = ""
    for part in [item for item in clean_path.split("/") if item]:
        current = remote_join(current or "/", part)
        crumbs.append({"name": part, "path": current})
    return crumbs


def normalize_cloud_entry(base_path: str, entry: dict) -> dict:
    name = str(entry.get("name", "") or "").strip()
    entry_type = str(entry.get("type", "") or "").strip()
    is_dir = is_remote_dir_type(entry_type)
    size_value = entry.get("size")
    try:
        size_bytes = int(size_value)
    except (TypeError, ValueError):
        size_bytes = None
    modified_value = entry.get("last_modified")
    try:
        last_modified = int(modified_value)
    except (TypeError, ValueError):
        last_modified = 0

    return {
        "name": name,
        "path": remote_join(base_path, name),
        "type": "folder" if is_dir else "file",
        "sizeBytes": None if is_dir else size_bytes,
        "lastModified": last_modified,
        "isZip": (not is_dir) and name.lower().endswith(".zip"),
    }


def sort_cloud_entries(entries: list[dict]) -> list[dict]:
    return sorted(
        entries,
        key=lambda item: (0 if item.get("type") == "folder" else 1, str(item.get("name", "")).lower()),
    )


def get_network_status(timeout: float = 1.4) -> dict:
    errors: list[str] = []
    started_at = time.time()
    for host, port in NETWORK_CHECK_HOSTS:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return {
                    "online": True,
                    "host": host,
                    "latencyMs": max(0, round((time.time() - started_at) * 1000)),
                }
        except OSError as error:
            errors.append(f"{host}:{port} {error}")
    return {
        "online": False,
        "host": "",
        "latencyMs": max(0, round((time.time() - started_at) * 1000)),
        "errors": errors[-3:],
    }


def is_leaker_proxy_path(path: str) -> bool:
    clean_path = str(path or "")
    if clean_path == LEAKER_PROXY_PREFIX or clean_path.startswith(f"{LEAKER_PROXY_PREFIX}/"):
        return True
    if clean_path.startswith("/_next/") or clean_path.startswith("/cdn-cgi/"):
        return True
    if clean_path.startswith("/api/"):
        return True
    for prefix in (
        "/dashboard",
        "/requests",
        "/resources",
        "/auth",
        "/login",
        "/signin",
        "/password",
        "/membership",
        "/verify",
        "/favicon",
    ):
        if clean_path == prefix or clean_path.startswith(f"{prefix}/"):
            return True
    return False


def is_leaker_site_root_request(parsed: urllib.parse.SplitResult, headers=None) -> bool:
    if parsed.path != "/":
        return False
    params = urllib.parse.parse_qs(parsed.query or "", keep_blank_values=True)
    if "callbackUrl" in params or "_rsc" in params:
        return True

    referer = ""
    try:
        referer = str(headers.get("Referer", "") if headers is not None else "")
    except Exception:
        referer = ""
    if not referer:
        return False

    try:
        ref = urllib.parse.urlsplit(referer)
    except ValueError:
        return False

    ref_host = ref.netloc.lower().split("@")[-1].split(":")[0]
    if ref_host not in {"127.0.0.1", "localhost"}:
        return False

    ref_path = ref.path or "/"
    return is_leaker_proxy_path(ref_path) or ref_path == LEAKER_OAUTH_BRIDGE_PATH


def leaker_upstream_path(path: str) -> str:
    clean_path = str(path or "/")
    if clean_path == LEAKER_PROXY_PREFIX:
        return "/"
    if clean_path.startswith(f"{LEAKER_PROXY_PREFIX}/"):
        return clean_path[len(LEAKER_PROXY_PREFIX) :] or "/"
    return clean_path or "/"


def leaker_proxy_location(location: str) -> str:
    raw = str(location or "").strip()
    if not raw:
        return raw
    try:
        parsed = urllib.parse.urlsplit(raw)
    except ValueError:
        parsed = None
    if parsed and parsed.scheme and parsed.netloc:
        host = parsed.netloc.lower().split("@")[-1].split(":")[0]
        if parsed.scheme in {"http", "https"} and host == "6ureleaks.com":
            path = parsed.path or "/"
            query = f"?{parsed.query}" if parsed.query else ""
            fragment = f"#{parsed.fragment}" if parsed.fragment else ""
            return f"{path}{query}{fragment}"
        return raw
    if raw.startswith("/"):
        return raw
    return raw


def is_discord_oauth_url(url: str) -> bool:
    try:
        parsed = urllib.parse.urlsplit(str(url or "").strip())
    except ValueError:
        return False
    host = parsed.netloc.lower().split("@")[-1].split(":")[0]
    path = parsed.path.lower()
    return (
        parsed.scheme == "https"
        and host in DISCORD_OAUTH_HOSTS
        and (path == "/oauth2/authorize" or path == "/api/oauth2/authorize")
    )


def normalize_discord_oauth_url(url: str) -> str:
    clean_url = html.unescape(str(url or "").strip())
    clean_url = clean_url.replace("\\/", "/")
    clean_url = re.sub(r"\\u0026", "&", clean_url, flags=re.IGNORECASE)
    clean_url = re.sub(r"\\u003d", "=", clean_url, flags=re.IGNORECASE)
    clean_url = re.sub(r"\\u003f", "?", clean_url, flags=re.IGNORECASE)
    clean_url = re.sub(r"\\u002f", "/", clean_url, flags=re.IGNORECASE)
    return clean_url.rstrip("\\")


def leaker_discord_oauth_bridge_url(url: str) -> str:
    clean_url = normalize_discord_oauth_url(url)
    return f"{LEAKER_OAUTH_BRIDGE_PATH}?url={urllib.parse.quote(clean_url, safe='')}"


def rewrite_discord_oauth_urls(text: str) -> str:
    if not text or "discord" not in text.lower():
        return text

    pattern = re.compile(
        r"""https:(?://|\\/\\/)(?:(?:canary|ptb)\.)?(?:discord\.com|discordapp\.com)(?:/|\\/)(?:api(?:/|\\/))?oauth2(?:/|\\/)authorize[^\s"'<>)]*""",
        flags=re.IGNORECASE,
    )

    def replace(match: re.Match) -> str:
        raw_url = match.group(0)
        clean_url = normalize_discord_oauth_url(raw_url)
        if not is_discord_oauth_url(clean_url):
            return raw_url
        return leaker_discord_oauth_bridge_url(clean_url)

    return pattern.sub(replace, text)


def leaker_discord_oauth_bridge_script() -> str:
    return r"""<script>
(() => {
  const DISCORD_OAUTH_RE = /^https:\/\/(?:(?:canary|ptb)\.)?(?:discord\.com|discordapp\.com)\/(?:api\/)?oauth2\/authorize\b/i;
  const LOCAL_BRIDGE_RE = /^(?:https?:\/\/[^/]+)?\/leaker-oauth\/bridge\b/i;

  function resolveDiscordOAuthUrl(url) {
    const cleanUrl = String(url || '');
    if (DISCORD_OAUTH_RE.test(cleanUrl)) return cleanUrl;
    if (!LOCAL_BRIDGE_RE.test(cleanUrl)) return '';
    try {
      const parsed = new URL(cleanUrl, window.location.origin);
      const oauthUrl = parsed.searchParams.get('url') || '';
      return DISCORD_OAUTH_RE.test(oauthUrl) ? oauthUrl : '';
    } catch {
      return '';
    }
  }

  function notifyDiscordOAuth(url) {
    const cleanUrl = resolveDiscordOAuthUrl(url);
    if (!cleanUrl) return false;
    try {
      window.parent.postMessage({ type: '6ure-discord-oauth', url: cleanUrl }, window.location.origin);
    } catch {}
    return true;
  }

  document.addEventListener('click', event => {
    const link = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!link || !notifyDiscordOAuth(link.href)) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);

  document.addEventListener('submit', event => {
    const form = event.target;
    if (!form || !notifyDiscordOAuth(form.action)) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);

  const originalOpen = window.open;
  window.open = function(url, target, features) {
    if (notifyDiscordOAuth(url)) return null;
    return originalOpen ? originalOpen.apply(window, arguments) : null;
  };
})();
</script>"""


def inject_leaker_discord_oauth_bridge(text: str) -> str:
    if not text:
        return text
    script = leaker_discord_oauth_bridge_script()
    if "6ure-discord-oauth" in text:
        return text
    if re.search(r"</body\s*>", text, flags=re.IGNORECASE):
        return re.sub(r"</body\s*>", script + r"</body>", text, count=1, flags=re.IGNORECASE)
    return text + script


def leaker_discord_oauth_bridge_html(url: str) -> str:
    safe_url = json.dumps(str(url or ""))
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Discord OAuth</title>
  <style>
    :root {{ color-scheme: dark; }}
    * {{ box-sizing: border-box; }}
    html, body {{
      width: 100%;
      height: 100%;
      margin: 0;
      background: #080910;
      color: #f7f5ff;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }}
    body {{
      display: grid;
      place-items: center;
      padding: 24px;
      text-align: center;
    }}
    main {{
      display: grid;
      gap: 10px;
      max-width: 420px;
    }}
    strong {{ font-size: 17px; font-weight: 950; }}
    span {{ color: #a4a0c5; font-size: 13px; font-weight: 800; line-height: 1.45; }}
  </style>
</head>
<body>
  <main>
    <strong>Discord OAuth is opening.</strong>
    <span>Complete Discord login in the separate window. Leaker Mode will continue here automatically.</span>
  </main>
  <script>
    const oauthUrl = {safe_url};
    function notifyParent() {{
      try {{
        window.parent.postMessage({{ type: '6ure-discord-oauth', url: oauthUrl }}, window.location.origin);
      }} catch {{}}
    }}
    notifyParent();
    setTimeout(notifyParent, 300);
    setTimeout(notifyParent, 900);
  </script>
</body>
</html>"""


def cookie_expiry_timestamp(value) -> int | None:
    if value in (None, "", False):
        return None
    if isinstance(value, (int, float)):
        return int(value) if value > 0 else None
    try:
        parsed = email.utils.parsedate_to_datetime(str(value))
        return int(parsed.timestamp())
    except Exception:
        return None


def iter_webview_cookie_records(cookies):
    if not cookies:
        return
    if isinstance(cookies, http.cookies.SimpleCookie):
        for morsel in cookies.values():
            yield {
                "name": morsel.key,
                "value": morsel.value,
                "domain": morsel["domain"],
                "path": morsel["path"],
                "expires": morsel["expires"],
                "secure": morsel["secure"],
            }
        return
    if isinstance(cookies, dict):
        if "name" in cookies and "value" in cookies:
            yield cookies
            return
        for name, value in cookies.items():
            if isinstance(value, dict):
                record = dict(value)
                record.setdefault("name", name)
                yield record
            else:
                yield {"name": name, "value": value}
        return
    if isinstance(cookies, (list, tuple, set)):
        for item in cookies:
            yield from iter_webview_cookie_records(item)


def sync_leaker_proxy_cookies_from_webview(cookies) -> int:
    synced = 0
    with LEAKER_PROXY_LOCK:
        for record in iter_webview_cookie_records(cookies):
            name = str(record.get("name", "") or "").strip()
            value = str(record.get("value", "") or "")
            if not name:
                continue
            domain = str(record.get("domain", "") or "").strip().lower()
            if domain.startswith("."):
                clean_domain = domain[1:]
            else:
                clean_domain = domain
            if clean_domain and clean_domain != "6ureleaks.com" and not clean_domain.endswith(".6ureleaks.com"):
                continue
            domain = domain or ".6ureleaks.com"
            path = str(record.get("path", "") or "/").strip() or "/"
            secure = bool(record.get("secure", True))
            kwargs = {"domain": domain, "path": path, "secure": secure}
            expires = cookie_expiry_timestamp(record.get("expires"))
            if expires:
                kwargs["expires"] = expires
            cookie = requests.cookies.create_cookie(name=name, value=value, **kwargs)
            LEAKER_PROXY_SESSION.cookies.set_cookie(cookie)
            synced += 1
        if synced:
            try:
                LEAKER_PROXY_SESSION.cookies.save(ignore_discard=True, ignore_expires=True)
            except Exception:
                pass
    return synced


def rewrite_leaker_proxy_text(text: str) -> str:
    if not text:
        return text

    rewritten = rewrite_discord_oauth_urls(text)
    rewritten = re.sub(
        r"""(?i)https?://6ureleaks\.com(?P<path>/[^\s"'`<>)]*)?""",
        lambda match: match.group("path") or "/",
        rewritten,
    )

    return rewritten


def should_rewrite_leaker_content(content_type: str) -> bool:
    clean_type = str(content_type or "").lower()
    return (
        clean_type.startswith("text/")
        or "javascript" in clean_type
        or "application/json" in clean_type
    )


def should_rewrite_leaker_page(content_type: str, upstream_path: str) -> bool:
    return False


class FilesAutomationError(Exception):
    pass


class FilesDuplicateLeakError(FilesAutomationError):
    def __init__(self, remote_path: str) -> None:
        clean_remote_path = str(remote_path or "").strip().lstrip("/")
        self.remote_path = clean_remote_path
        super().__init__(f"This leak is available in cloud already: {clean_remote_path}")


class FilesProtectedNameError(FilesAutomationError):
    def __init__(self, matches: list[dict]) -> None:
        self.matches = matches
        names = ", ".join(
            f"{item.get('candidateName')} -> {item.get('protectedName')}"
            for item in matches[:5]
            if item.get("candidateName") and item.get("protectedName")
        )
        suffix = f": {names}" if names else "."
        super().__init__(f"Protected name detected{suffix}")


class FilesUploadCancelledError(FilesAutomationError):
    def __init__(self) -> None:
        super().__init__("Upload was cancelled by the user.")


def normalize_protected_key(value: str) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold().strip()
    text = text.lstrip("@")
    return "".join(char for char in text if char.isalnum())


def protected_name_tokens(value: str) -> set[str]:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return {normalize_protected_key(token) for token in re.split(r"[^\w@]+", text) if normalize_protected_key(token)}


def add_protected_alias(aliases: list[str], value: str) -> None:
    text = str(value or "").strip()
    if not text:
        return
    candidates = [text]
    if text.startswith("@"):
        candidates.append(text[1:])
    for candidate in candidates:
        key = normalize_protected_key(candidate)
        if key and key not in {normalize_protected_key(alias) for alias in aliases}:
            aliases.append(candidate.strip())


def extract_social_aliases(social_link: str) -> list[str]:
    aliases: list[str] = []
    link = str(social_link or "").strip()
    if not link:
        return aliases
    try:
        parsed = urllib.parse.urlsplit(link)
    except ValueError:
        return aliases
    path_parts = [urllib.parse.unquote(part) for part in parsed.path.split("/") if part.strip()]
    for part in path_parts:
        clean = part.strip()
        if clean.startswith("@"):
            add_protected_alias(aliases, clean)
        elif parsed.netloc.lower().endswith("youtube.com") and clean.startswith("@"):
            add_protected_alias(aliases, clean)
    return aliases


def protected_text_value(item: dict, field: str) -> str:
    return str(item.get(field, "") or "").strip()


def clean_protected_image_url(value: str) -> str:
    url = str(value or "").strip()
    if not url:
        return ""
    nested_index = url.find("https://", len("https://"))
    if nested_index > 0:
        url = url[nested_index:]
    url = re.sub(
        r"(\.(?:png|jpe?g|webp|gif))\?size=\d+\.(?:png|jpe?g|webp|gif)\?size=(\d+)",
        r"\1?size=\2",
        url,
        flags=re.IGNORECASE,
    )
    return url


def protected_public_record(item: dict) -> dict:
    clean: dict = {}
    for key, value in item.items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            clean[str(key)] = value
        else:
            clean[str(key)] = str(value)
    if "avatar" in clean:
        clean["avatar"] = clean_protected_image_url(str(clean.get("avatar") or ""))
    if "creatorAvatar" in clean:
        clean["creatorAvatar"] = clean_protected_image_url(str(clean.get("creatorAvatar") or ""))
    return clean


def fetch_protected_users() -> list[dict]:
    try:
        response = requests.get(
            PROTECTED_LIST_API_URL,
            timeout=30,
            headers={
                "Accept": "application/json",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "Referer": PROTECTED_LIST_PAGE_URL,
                "User-Agent": "6ure Files protected-check",
            },
        )
    except requests.RequestException as error:
        raise FilesAutomationError("Protected list could not be loaded from 6ureleaks.com.") from error
    if response.status_code != 200:
        raise FilesAutomationError(f"Protected list returned HTTP {response.status_code}.")
    try:
        payload = response.json()
    except ValueError as error:
        raise FilesAutomationError("Protected list is not valid JSON.") from error
    if isinstance(payload, dict) and isinstance(payload.get("value"), list):
        payload = payload["value"]
    if not isinstance(payload, list):
        raise FilesAutomationError("Protected list response is invalid.")
    return [item for item in payload if isinstance(item, dict)]


def normalize_protected_user(item: dict) -> dict:
    aliases: list[str] = []
    for field in ("username", "displayName", "creatorName"):
        add_protected_alias(aliases, str(item.get(field, "") or ""))
    for alias in extract_social_aliases(str(item.get("socialLink", "") or "")):
        add_protected_alias(aliases, alias)
    name = (
        str(item.get("creatorName", "") or "").strip()
        or str(item.get("displayName", "") or "").strip()
        or str(item.get("username", "") or "").strip()
        or (aliases[0] if aliases else "Unknown")
    )
    raw = protected_public_record(item)
    return {
        "name": name,
        "userId": protected_text_value(item, "userId"),
        "username": protected_text_value(item, "username"),
        "avatar": clean_protected_image_url(protected_text_value(item, "avatar")),
        "avatarDecoration": protected_text_value(item, "avatar_decoration"),
        "displayName": protected_text_value(item, "displayName"),
        "subscriptionEndsAt": protected_text_value(item, "subscriptionEndsAt"),
        "subscriptionEndsAtManual": protected_text_value(item, "subscriptionEndsAtManual"),
        "subscriptionDateSource": protected_text_value(item, "subscriptionDateSource"),
        "migratedLpSubscriber": bool(item.get("migratedLpSubscriber", False)),
        "socialLink": protected_text_value(item, "socialLink"),
        "creatorName": protected_text_value(item, "creatorName"),
        "creatorAvatar": clean_protected_image_url(protected_text_value(item, "creatorAvatar")),
        "creatorPlatform": protected_text_value(item, "creatorPlatform"),
        "followerCount": item.get("followerCount"),
        "videoCount": item.get("videoCount"),
        "likesCount": item.get("likesCount"),
        "verified": item.get("verified"),
        "creatorBio": protected_text_value(item, "creatorBio"),
        "creatorBioLink": protected_text_value(item, "creatorBioLink"),
        "aliases": aliases,
        "raw": raw,
    }


def get_protected_list_payload() -> dict:
    users = [normalize_protected_user(item) for item in fetch_protected_users()]
    users = [item for item in users if item["aliases"]]
    return {
        "sourceUrl": PROTECTED_LIST_PAGE_URL,
        "apiUrl": PROTECTED_LIST_API_URL,
        "checkedAt": int(time.time() * 1000),
        "count": len(users),
        "users": users,
    }


def protected_alias_matches(candidate_name: str, alias: str) -> bool:
    candidate_key = normalize_protected_key(candidate_name)
    alias_key = normalize_protected_key(alias)
    if not candidate_key or not alias_key:
        return False
    if candidate_key == alias_key:
        return True
    tokens = protected_name_tokens(candidate_name)
    if len(alias_key) >= 3 and alias_key in tokens:
        return True
    return len(alias_key) >= 4 and alias_key in candidate_key


def check_protected_names(candidate_names: list[str]) -> dict:
    protected_payload = get_protected_list_payload()
    clean_candidates: list[str] = []
    seen_candidates: set[str] = set()
    for name in candidate_names:
        clean_name = str(name or "").strip()
        key = clean_name.casefold()
        if clean_name and key not in seen_candidates:
            seen_candidates.add(key)
            clean_candidates.append(clean_name)

    matches: list[dict] = []
    seen_matches: set[tuple[str, str, str]] = set()
    for candidate in clean_candidates:
        for user in protected_payload["users"]:
            for alias in user.get("aliases", []):
                if not protected_alias_matches(candidate, alias):
                    continue
                key = (candidate.casefold(), str(user.get("name", "")).casefold(), str(alias).casefold())
                if key in seen_matches:
                    continue
                seen_matches.add(key)
                matches.append(
                    {
                        "candidateName": candidate,
                        "protectedName": user.get("name", ""),
                        "matchedAlias": alias,
                        "userId": user.get("userId", ""),
                        "username": user.get("username", ""),
                        "displayName": user.get("displayName", ""),
                        "avatar": user.get("avatar", ""),
                        "creatorName": user.get("creatorName", ""),
                        "creatorAvatar": user.get("creatorAvatar", ""),
                        "creatorPlatform": user.get("creatorPlatform", ""),
                        "socialLink": user.get("socialLink", ""),
                        "subscriptionEndsAt": user.get("subscriptionEndsAt", ""),
                        "user": user,
                    }
                )
                break

    return {
        "sourceUrl": protected_payload["sourceUrl"],
        "checkedAt": protected_payload["checkedAt"],
        "protectedCount": protected_payload["count"],
        "checkedNames": clean_candidates,
        "matches": matches,
        "blocked": bool(matches),
    }


def protected_match_label(match: dict) -> str:
    label = (
        str(match.get("creatorName", "") or "").strip()
        or str(match.get("displayName", "") or "").strip()
        or str(match.get("username", "") or "").strip()
        or str(match.get("protectedName", "") or "").strip()
        or str(match.get("matchedAlias", "") or "").strip()
        or "This creator"
    )
    if label != "This creator" and not label.startswith("@"):
        creator_platform = str(match.get("creatorPlatform", "") or "").strip().lower()
        if creator_platform in {"tiktok", "instagram", "youtube", "twitter", "x"}:
            label = "@" + label
    return label


def protected_publish_warning(matches: list[dict]) -> str:
    labels: list[str] = []
    seen: set[str] = set()
    for match in matches:
        label = protected_match_label(match)
        key = label.casefold()
        if label and key not in seen:
            seen.add(key)
            labels.append(label)
    if not labels:
        return "A protected creator was detected. You can't post this leak to 6ureleaks.com/resources."
    if len(labels) == 1:
        return f"{labels[0]} is protected. You can't post this leak to 6ureleaks.com/resources."
    return f"{', '.join(labels[:4])} are protected. You can't post this leak to 6ureleaks.com/resources."


def unique_config_paths(candidates: list[Path]) -> list[Path]:
    unique: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        try:
            key = os.path.normcase(str(path.expanduser().resolve()))
        except OSError:
            key = os.path.normcase(str(path.expanduser()))
        if key in seen:
            continue
        seen.add(key)
        unique.append(path)
    return unique


def discord_presence_config_paths() -> list[Path]:
    candidates = [
        ROOT / DISCORD_PRESENCE_CONFIG_FILE_NAME,
        APP_ROOT / DISCORD_PRESENCE_CONFIG_FILE_NAME,
        DATA_ROOT / DISCORD_PRESENCE_CONFIG_FILE_NAME,
    ]
    configured_path = str(os.environ.get("REYLI_DISCORD_PRESENCE_CONFIG_PATH", "") or "").strip()
    if configured_path:
        candidates.append(Path(configured_path))
    return unique_config_paths(candidates)


def start_discord_presence() -> DiscordPresenceManager:
    global DISCORD_PRESENCE
    with DISCORD_PRESENCE_LOCK:
        if DISCORD_PRESENCE is None:
            config = load_presence_config(discord_presence_config_paths())
            DISCORD_PRESENCE = DiscordPresenceManager(config)
            DISCORD_PRESENCE.start()
        return DISCORD_PRESENCE


def stop_discord_presence() -> None:
    global DISCORD_PRESENCE
    with DISCORD_PRESENCE_LOCK:
        manager = DISCORD_PRESENCE
        DISCORD_PRESENCE = None
    if manager is not None:
        manager.shutdown()


def set_discord_presence_activity(
    *,
    details: str | None = None,
    state: str | None = None,
    small_image: str | None = None,
    small_text: str | None = None,
) -> dict:
    manager = start_discord_presence()
    return manager.set_activity(details=details, state=state, small_image=small_image, small_text=small_text)


def get_discord_presence_status() -> dict:
    return start_discord_presence().status()


def refresh_discord_presence_from_session() -> None:
    session = get_session_snapshot()
    if session["authenticated"]:
        set_discord_presence_activity(details="Managing 6ure Files", state="Ready to upload")
    else:
        set_discord_presence_activity(details="6ure Files", state="Waiting for sign in")


def update_config_paths() -> list[Path]:
    candidates = [ROOT / UPDATE_CONFIG_FILE_NAME, APP_ROOT / UPDATE_CONFIG_FILE_NAME, DATA_ROOT / UPDATE_CONFIG_FILE_NAME]
    return unique_config_paths(candidates)


atexit.register(stop_discord_presence)



def load_update_config() -> dict:
    config: dict = {}
    for path in update_config_paths():
        payload = read_state_file(path)
        if isinstance(payload, dict):
            config.update(payload)

    env_manifest_url = str(os.environ.get("REYLI_UPDATE_MANIFEST_URL", "") or "").strip()
    if env_manifest_url:
        config["manifestUrl"] = env_manifest_url
    env_channel = str(os.environ.get("REYLI_UPDATE_CHANNEL", "") or "").strip()
    if env_channel:
        config["channel"] = env_channel
    return config


def get_update_manifest_url(config: dict | None = None) -> str:
    current = config if isinstance(config, dict) else load_update_config()
    return str(current.get("manifestUrl") or current.get("manifest_url") or "").strip()


def allow_insecure_update_url(config: dict | None = None) -> bool:
    current = config if isinstance(config, dict) else load_update_config()
    return bool(current.get("allowInsecure") or current.get("allow_insecure")) or os.environ.get(
        "REYLI_ALLOW_INSECURE_UPDATES"
    ) == "1"


def ensure_update_url_allowed(url: str, config: dict | None = None) -> None:
    parsed = urllib.parse.urlsplit(str(url or "").strip())
    if parsed.scheme == "https":
        return
    if allow_insecure_update_url(config) and parsed.scheme in {"http", "file"}:
        return
    raise FilesAutomationError("Update URLs must use HTTPS.")


def file_url_to_path(url: str) -> Path:
    parsed = urllib.parse.urlsplit(url)
    raw_path = urllib.parse.unquote(parsed.path or "")
    if os.name == "nt" and re.match(r"^/[A-Za-z]:", raw_path):
        raw_path = raw_path[1:]
    return Path(raw_path)


def read_update_json(url: str, config: dict) -> dict:
    ensure_update_url_allowed(url, config)
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme == "file":
        payload = read_state_file(file_url_to_path(url))
        if not isinstance(payload, dict):
            raise FilesAutomationError("Update manifest is invalid.")
        return payload

    response = requests.get(url, timeout=30, headers={"Cache-Control": "no-cache"})
    if response.status_code != 200:
        raise FilesAutomationError(f"Update manifest returned HTTP {response.status_code}.")
    try:
        payload = response.json()
    except ValueError as error:
        raise FilesAutomationError("Update manifest is not valid JSON.") from error
    if not isinstance(payload, dict):
        raise FilesAutomationError("Update manifest is invalid.")
    return payload


def parse_version(value: str) -> tuple[int, ...]:
    text = str(value or "").strip().lower().lstrip("v")
    parts = re.split(r"[^0-9]+", text)
    numbers = [int(part) for part in parts if part != ""]
    return tuple(numbers or [0])


def is_newer_version(candidate: str, current: str = APP_VERSION) -> bool:
    candidate_parts = list(parse_version(candidate))
    current_parts = list(parse_version(current))
    length = max(len(candidate_parts), len(current_parts))
    candidate_parts.extend([0] * (length - len(candidate_parts)))
    current_parts.extend([0] * (length - len(current_parts)))
    return tuple(candidate_parts) > tuple(current_parts)


def current_update_platform_key() -> str:
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    return "linux"


def normalize_update_manifest(manifest: dict, manifest_url: str) -> dict:
    platform_key = current_update_platform_key()
    platform_payload = manifest.get(platform_key)
    if not isinstance(platform_payload, dict) and platform_key == "macos":
        platform_payload = manifest.get("darwin")
    if not isinstance(platform_payload, dict):
        platform_payload = manifest.get("package") if isinstance(manifest.get("package"), dict) else manifest

    version = str(platform_payload.get("version") or manifest.get("version") or "").strip().lstrip("v")
    package_url = str(platform_payload.get("url") or manifest.get("url") or "").strip()
    sha256 = str(platform_payload.get("sha256") or manifest.get("sha256") or "").strip().lower()
    notes = str(platform_payload.get("notes") or manifest.get("notes") or "").strip()
    mandatory = bool(platform_payload.get("mandatory") or manifest.get("mandatory"))
    size_bytes = platform_payload.get("sizeBytes", manifest.get("sizeBytes"))
    package_type = str(
        platform_payload.get("packageType") or platform_payload.get("type") or manifest.get("packageType") or ""
    ).strip().lower()
    package_url = urllib.parse.urljoin(manifest_url, package_url) if package_url else ""
    package_path = urllib.parse.urlsplit(package_url).path.lower() if package_url else ""
    if package_type not in {"zip", "installer"}:
        package_type = "installer" if package_path.endswith((".exe", ".msi")) else "zip"

    installer_args = platform_payload.get("installerArgs", manifest.get("installerArgs", ""))
    if isinstance(installer_args, list):
        clean_installer_args = [str(item) for item in installer_args if str(item).strip()]
    else:
        clean_installer_args = str(installer_args or "").strip()

    success_exit_codes = platform_payload.get("successExitCodes", manifest.get("successExitCodes"))
    if isinstance(success_exit_codes, list):
        clean_success_exit_codes = []
        for code in success_exit_codes:
            try:
                clean_success_exit_codes.append(int(code))
            except (TypeError, ValueError):
                continue
        if not clean_success_exit_codes:
            clean_success_exit_codes = [0, 3010]
    else:
        clean_success_exit_codes = [0, 3010]

    if not version:
        raise FilesAutomationError("Update manifest is missing a version.")
    update_available = is_newer_version(version)
    if update_available:
        if not package_url:
            raise FilesAutomationError("Update manifest is missing a package URL.")
        if not re.fullmatch(r"[a-f0-9]{64}", sha256):
            raise FilesAutomationError("Update manifest is missing a valid SHA-256 checksum.")

    return {
        "version": version,
        "url": package_url,
        "sha256": sha256,
        "notes": notes,
        "mandatory": mandatory,
        "packageType": package_type,
        "installerArgs": clean_installer_args,
        "successExitCodes": clean_success_exit_codes,
        "sizeBytes": size_bytes if isinstance(size_bytes, int) and size_bytes >= 0 else None,
        "platform": platform_key,
        "updateAvailable": update_available,
    }


def check_for_update() -> dict:
    config = load_update_config()
    manifest_url = get_update_manifest_url(config)
    if not manifest_url:
        result = {
            "configured": False,
            "currentVersion": APP_VERSION,
            "updateAvailable": False,
            "msg": "Update manifest URL is not configured.",
        }
        with UPDATE_STATE_LOCK:
            UPDATE_STATE["lastCheckAt"] = int(time.time() * 1000)
            UPDATE_STATE["latest"] = None
            UPDATE_STATE["lastError"] = ""
        return result

    with UPDATE_STATE_LOCK:
        if UPDATE_STATE["checking"]:
            raise FilesAutomationError("Update check is already running.")
        UPDATE_STATE["checking"] = True
        UPDATE_STATE["lastError"] = ""

    try:
        manifest = read_update_json(manifest_url, config)
        latest = normalize_update_manifest(manifest, manifest_url)
        result = {
            "configured": True,
            "currentVersion": APP_VERSION,
            "latest": latest,
            "updateAvailable": bool(latest["updateAvailable"]),
            "msg": "Update available." if latest["updateAvailable"] else "You are on the latest version.",
        }
        with UPDATE_STATE_LOCK:
            UPDATE_STATE["lastCheckAt"] = int(time.time() * 1000)
            UPDATE_STATE["latest"] = latest
        return result
    except Exception as error:
        with UPDATE_STATE_LOCK:
            UPDATE_STATE["lastError"] = str(error)
        raise
    finally:
        with UPDATE_STATE_LOCK:
            UPDATE_STATE["checking"] = False


def get_update_status() -> dict:
    config = load_update_config()
    with UPDATE_STATE_LOCK:
        latest = UPDATE_STATE["latest"]
        return {
            "configured": bool(get_update_manifest_url(config)),
            "currentVersion": APP_VERSION,
            "checking": bool(UPDATE_STATE["checking"]),
            "installing": bool(UPDATE_STATE["installing"]),
            "lastCheckAt": UPDATE_STATE["lastCheckAt"],
            "lastError": UPDATE_STATE["lastError"],
            "latest": latest,
            "updateAvailable": bool(isinstance(latest, dict) and latest.get("updateAvailable")),
            "installPhase": UPDATE_STATE["installPhase"],
            "installMessage": UPDATE_STATE["installMessage"],
            "downloadedBytes": UPDATE_STATE["downloadedBytes"],
            "totalBytes": UPDATE_STATE["totalBytes"],
            "installProgress": UPDATE_STATE["installProgress"],
            "installStartedAt": UPDATE_STATE["installStartedAt"],
            "installUpdatedAt": UPDATE_STATE["installUpdatedAt"],
        }


def set_update_install_status(
    phase: str,
    message: str,
    *,
    downloaded_bytes: int | None = None,
    total_bytes: int | None = None,
    progress: int | None = None,
) -> None:
    with UPDATE_STATE_LOCK:
        UPDATE_STATE["installPhase"] = str(phase or "")
        UPDATE_STATE["installMessage"] = str(message or "")
        if downloaded_bytes is not None:
            UPDATE_STATE["downloadedBytes"] = max(0, int(downloaded_bytes))
        if total_bytes is not None:
            UPDATE_STATE["totalBytes"] = max(0, int(total_bytes)) if int(total_bytes) >= 0 else None
        if progress is not None:
            UPDATE_STATE["installProgress"] = max(0, min(100, int(progress)))
        UPDATE_STATE["installUpdatedAt"] = int(time.time() * 1000)


def reset_update_install_status() -> None:
    with UPDATE_STATE_LOCK:
        UPDATE_STATE["installPhase"] = ""
        UPDATE_STATE["installMessage"] = ""
        UPDATE_STATE["downloadedBytes"] = 0
        UPDATE_STATE["totalBytes"] = None
        UPDATE_STATE["installProgress"] = 0
        UPDATE_STATE["installStartedAt"] = int(time.time() * 1000)
        UPDATE_STATE["installUpdatedAt"] = UPDATE_STATE["installStartedAt"]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_update_package(update_info: dict) -> Path:
    package_url = str(update_info.get("url", "") or "").strip()
    expected_sha256 = str(update_info.get("sha256", "") or "").strip().lower()
    ensure_update_url_allowed(package_url, load_update_config())

    UPDATE_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    version = re.sub(r"[^A-Za-z0-9._-]+", "-", str(update_info.get("version", "update") or "update"))
    package_type = str(update_info.get("packageType") or "").strip().lower()
    url_path = urllib.parse.urlsplit(package_url).path.lower()
    if package_type == "installer":
        extension = ".msi" if url_path.endswith(".msi") else ".exe"
    else:
        extension = ".zip"
    package_path = UPDATE_DOWNLOAD_DIR / f"6ure-files-{version}{extension}"
    temp_path = UPDATE_DOWNLOAD_DIR / f"{package_path.name}.tmp"
    downloaded = 0
    declared_size = update_info.get("sizeBytes")
    total_bytes = int(declared_size) if isinstance(declared_size, int) and declared_size >= 0 else None
    set_update_install_status(
        "download",
        f"Preparing download for v{update_info.get('version', '')}.",
        downloaded_bytes=0,
        total_bytes=total_bytes if total_bytes is not None else -1,
        progress=8,
    )

    parsed = urllib.parse.urlsplit(package_url)
    if parsed.scheme == "file":
        source_path = file_url_to_path(package_url)
        shutil.copyfile(source_path, temp_path)
        downloaded = temp_path.stat().st_size
        set_update_install_status(
            "download",
            "Copied local update package.",
            downloaded_bytes=downloaded,
            total_bytes=downloaded,
            progress=70,
        )
    else:
        with requests.get(package_url, timeout=60, stream=True) as response:
            if response.status_code != 200:
                raise FilesAutomationError(f"Update package returned HTTP {response.status_code}.")
            content_length = response.headers.get("Content-Length")
            if content_length and content_length.isdigit():
                total_bytes = int(content_length)
                set_update_install_status(
                    "download",
                    "Downloading update package.",
                    downloaded_bytes=0,
                    total_bytes=total_bytes,
                    progress=10,
                )
            with temp_path.open("wb") as handle:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if not chunk:
                        continue
                    downloaded += len(chunk)
                    if downloaded > UPDATE_MAX_PACKAGE_BYTES:
                        raise FilesAutomationError("Update package is larger than the configured safety limit.")
                    handle.write(chunk)
                    if total_bytes and total_bytes > 0:
                        download_progress = 10 + round((downloaded / total_bytes) * 60)
                    else:
                        download_progress = 20
                    set_update_install_status(
                        "download",
                        "Downloading update package.",
                        downloaded_bytes=downloaded,
                        total_bytes=total_bytes if total_bytes is not None else -1,
                        progress=min(70, download_progress),
                    )

    set_update_install_status(
        "verify",
        "Verifying update checksum.",
        downloaded_bytes=downloaded,
        total_bytes=total_bytes if total_bytes is not None else downloaded,
        progress=76,
    )
    actual_sha256 = sha256_file(temp_path)
    if actual_sha256.lower() != expected_sha256:
        try:
            temp_path.unlink()
        except OSError:
            pass
        raise FilesAutomationError("Update package checksum did not match the manifest.")

    os.replace(temp_path, package_path)
    set_update_install_status("ready", "Update package verified.", downloaded_bytes=downloaded, total_bytes=downloaded, progress=88)
    return package_path


def ps_single_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def ps_array(values: list[str | int]) -> str:
    if not values:
        return "@()"
    return "@(" + ", ".join(ps_single_quote(str(value)) for value in values) + ")"


def write_windows_zip_update_script(package_path: Path) -> Path:
    if not sys.platform.startswith("win"):
        raise FilesAutomationError("Automatic update install is currently supported on Windows only.")
    if not getattr(sys, "frozen", False):
        raise FilesAutomationError("Automatic update install is only available in the packaged app.")

    UPDATE_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    UPDATE_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    script_path = UPDATE_DOWNLOAD_DIR / "apply-6ure-files-update.ps1"
    exe_name = Path(sys.executable).name
    app_dir = APP_ROOT.resolve()
    exe_path = Path(sys.executable).resolve()
    backup_root = UPDATE_BACKUP_DIR.resolve()

    script = f"""
$ErrorActionPreference = "Stop"
$appDir = {ps_single_quote(str(app_dir))}
$zipPath = {ps_single_quote(str(package_path.resolve()))}
$backupRoot = {ps_single_quote(str(backup_root))}
$exeName = {ps_single_quote(exe_name)}
$exePath = {ps_single_quote(str(exe_path))}
$pidToWait = {os.getpid()}
$logPath = Join-Path $backupRoot "last-update.log"

function Write-UpdateLog {{
  param([string]$Message)
  $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  Add-Content -LiteralPath $logPath -Value "$stamp $Message"
}}

function Invoke-Retry {{
  param([scriptblock]$Action, [string]$Label)
  $lastError = $null
  for ($i = 1; $i -le 25; $i++) {{
    try {{
      & $Action
      return
    }} catch {{
      $lastError = $_
      Start-Sleep -Milliseconds 700
    }}
  }}
  throw "$Label failed: $lastError"
}}

try {{
  New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
  Write-UpdateLog "Waiting for process $pidToWait"
  try {{
    Wait-Process -Id $pidToWait -Timeout 90
  }} catch {{
    Start-Sleep -Seconds 3
  }}
  Start-Sleep -Milliseconds 900

  $stamp = Get-Date -Format "yyyyMMddHHmmss"
  $extractDir = Join-Path (Split-Path -Parent $zipPath) "payload-$stamp"
  $backupDir = Join-Path $backupRoot "backup-$stamp"
  New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
  New-Item -ItemType Directory -Force -Path $backupDir | Out-Null

  Write-UpdateLog "Extracting $zipPath"
  Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
  $payloadDir = $extractDir
  if (-not (Test-Path -LiteralPath (Join-Path $payloadDir $exeName))) {{
    $dirs = @(Get-ChildItem -LiteralPath $extractDir -Directory -Force)
    if ($dirs.Count -eq 1 -and (Test-Path -LiteralPath (Join-Path $dirs[0].FullName $exeName))) {{
      $payloadDir = $dirs[0].FullName
    }}
  }}
  if (-not (Test-Path -LiteralPath (Join-Path $payloadDir $exeName))) {{
    throw "Update package does not contain $exeName."
  }}

  Write-UpdateLog "Backing up $appDir"
  Get-ChildItem -LiteralPath $appDir -Force | Where-Object {{ $_.Name -ne "update-config.json" }} | ForEach-Object {{
    Copy-Item -LiteralPath $_.FullName -Destination $backupDir -Recurse -Force
  }}

  Write-UpdateLog "Removing old app files"
  Invoke-Retry -Label "Remove old app files" -Action {{
    Get-ChildItem -LiteralPath $appDir -Force | Where-Object {{ $_.Name -ne "update-config.json" }} | Remove-Item -Recurse -Force
  }}

  Write-UpdateLog "Copying new app files"
  Invoke-Retry -Label "Copy new app files" -Action {{
    Get-ChildItem -LiteralPath $payloadDir -Force | Where-Object {{ $_.Name -ne "update-config.json" }} | Copy-Item -Destination $appDir -Recurse -Force
  }}

  $targetConfig = Join-Path $appDir "update-config.json"
  $payloadConfig = Join-Path $payloadDir "update-config.json"
  if (-not (Test-Path -LiteralPath $targetConfig) -and (Test-Path -LiteralPath $payloadConfig)) {{
    Copy-Item -LiteralPath $payloadConfig -Destination $targetConfig -Force
  }}

  Write-UpdateLog "Starting updated app"
  Start-Process -FilePath (Join-Path $appDir $exeName) -WorkingDirectory $appDir
  Start-Sleep -Seconds 2
  Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue
  Write-UpdateLog "Update completed"
}} catch {{
  Write-UpdateLog ("Update failed: " + $_)
  try {{
    if ((Test-Path -LiteralPath $backupDir) -and (Test-Path -LiteralPath $appDir)) {{
      Get-ChildItem -LiteralPath $backupDir -Force | Copy-Item -Destination $appDir -Recurse -Force -ErrorAction SilentlyContinue
    }}
  }} catch {{}}
  if (Test-Path -LiteralPath $exePath) {{
    Start-Process -FilePath $exePath -WorkingDirectory $appDir
  }}
  exit 1
}}
""".strip()
    script_path.write_text(script, encoding="utf-8")
    return script_path


def write_windows_installer_update_script(package_path: Path, update_info: dict) -> Path:
    if not sys.platform.startswith("win"):
        raise FilesAutomationError("Automatic update install is currently supported on Windows only.")
    if not getattr(sys, "frozen", False):
        raise FilesAutomationError("Automatic update install is only available in the packaged app.")

    UPDATE_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    UPDATE_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    script_path = UPDATE_DOWNLOAD_DIR / "run-6ure-files-installer-update.ps1"
    app_dir = APP_ROOT.resolve()
    exe_path = Path(sys.executable).resolve()
    backup_root = UPDATE_BACKUP_DIR.resolve()
    installer_args = update_info.get("installerArgs", "")
    if isinstance(installer_args, list):
        installer_arg_items = [str(item) for item in installer_args if str(item).strip()]
    elif str(installer_args or "").strip():
        installer_arg_items = [str(installer_args).strip()]
    else:
        installer_arg_items = []
    success_codes = update_info.get("successExitCodes")
    if not isinstance(success_codes, list):
        success_codes = [0, 3010]
    clean_success_codes: list[int] = []
    for code in success_codes:
        try:
            clean_success_codes.append(int(code))
        except (TypeError, ValueError):
            continue
    if not clean_success_codes:
        clean_success_codes = [0, 3010]

    script = f"""
$ErrorActionPreference = "Stop"
$appDir = {ps_single_quote(str(app_dir))}
$installerPath = {ps_single_quote(str(package_path.resolve()))}
$exePath = {ps_single_quote(str(exe_path))}
$backupRoot = {ps_single_quote(str(backup_root))}
$installerArgs = {ps_array(installer_arg_items)}
$successExitCodes = @({", ".join(str(code) for code in clean_success_codes)})
$pidToWait = {os.getpid()}
$logPath = Join-Path $backupRoot "last-update.log"

function Write-UpdateLog {{
  param([string]$Message)
  $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  Add-Content -LiteralPath $logPath -Value "$stamp $Message"
}}

try {{
  New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
  Write-UpdateLog "Waiting for process $pidToWait"
  try {{
    Wait-Process -Id $pidToWait -Timeout 90
  }} catch {{
    Start-Sleep -Seconds 3
  }}
  Start-Sleep -Milliseconds 900

  Write-UpdateLog "Running installer $installerPath"
  if ($installerArgs.Count -gt 0) {{
    $proc = Start-Process -FilePath $installerPath -ArgumentList $installerArgs -Wait -PassThru
  }} else {{
    $proc = Start-Process -FilePath $installerPath -Wait -PassThru
  }}
  if ($null -ne $proc -and $successExitCodes -notcontains $proc.ExitCode) {{
    throw "Installer exited with code $($proc.ExitCode)."
  }}

  if (Test-Path -LiteralPath $exePath) {{
    Write-UpdateLog "Starting updated app"
    Start-Process -FilePath $exePath -WorkingDirectory (Split-Path -Parent $exePath)
  }}
  Write-UpdateLog "Installer update completed"
}} catch {{
  Write-UpdateLog ("Installer update failed: " + $_)
  if (Test-Path -LiteralPath $exePath) {{
    Start-Process -FilePath $exePath -WorkingDirectory (Split-Path -Parent $exePath)
  }}
  exit 1
}}
""".strip()
    script_path.write_text(script, encoding="utf-8")
    return script_path


def launch_windows_update_installer(package_path: Path, update_info: dict) -> None:
    package_type = str(update_info.get("packageType") or "").strip().lower()
    script_path = (
        write_windows_installer_update_script(package_path, update_info)
        if package_type == "installer"
        else write_windows_zip_update_script(package_path)
    )
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script_path),
        ],
        cwd=str(APP_ROOT),
        close_fds=True,
        creationflags=creationflags,
    )


def prepare_update_install() -> dict:
    if not sys.platform.startswith("win"):
        raise FilesAutomationError("Automatic update install is currently supported on Windows only.")
    if not getattr(sys, "frozen", False):
        raise FilesAutomationError("Automatic update install is only available in the packaged app.")

    with UPDATE_STATE_LOCK:
        if UPDATE_STATE["installing"]:
            raise FilesAutomationError("Update install is already running.")
        UPDATE_STATE["installing"] = True
        latest = UPDATE_STATE["latest"]
    reset_update_install_status()

    try:
        if not isinstance(latest, dict) or not latest.get("updateAvailable"):
            set_update_install_status("check", "Checking latest update manifest.", progress=3)
            latest_result = check_for_update()
            latest = latest_result.get("latest")
        if not isinstance(latest, dict) or not latest.get("updateAvailable"):
            raise FilesAutomationError("No update is available.")

        set_update_install_status("download", f"Starting update v{latest.get('version', '')}.", progress=6)
        package_path = download_update_package(latest)
        set_update_install_status("launch", "Launching installer and closing app.", progress=94)
        launch_windows_update_installer(package_path, latest)
        set_update_install_status("handoff", "Installer launched. The app will close now.", progress=100)
        return {
            "currentVersion": APP_VERSION,
            "latest": latest,
            "packagePath": str(package_path),
        }
    except Exception as error:
        with UPDATE_STATE_LOCK:
            UPDATE_STATE["lastError"] = str(error)
        set_update_install_status("error", str(error), progress=0)
        raise
    finally:
        with UPDATE_STATE_LOCK:
            if UPDATE_STATE["installPhase"] not in {"handoff", "launch"}:
                UPDATE_STATE["installing"] = False


WINDOWS_INVALID_ZIP_NAME_CHARS = set('<>:"|?*')


def zip_member_relative_path(info: zipfile.ZipInfo) -> Path | None:
    raw_name = str(info.filename or "").replace("\\", "/")
    if not raw_name:
        return None
    if raw_name.startswith("/") or re.match(r"^[A-Za-z]:", raw_name):
        raise FilesAutomationError(f"ZIP member has an unsafe path: {raw_name}")

    parts: list[str] = []
    for part in raw_name.split("/"):
        if part in {"", "."}:
            continue
        if part == ".." or "\x00" in part:
            raise FilesAutomationError(f"ZIP member has an unsafe path: {raw_name}")
        if os.name == "nt" and any(char in WINDOWS_INVALID_ZIP_NAME_CHARS for char in part):
            raise FilesAutomationError(f"ZIP member cannot be extracted on Windows: {raw_name}")
        parts.append(part)

    if not parts:
        return None
    return Path(*parts)


def path_is_within(root: Path, candidate: Path) -> bool:
    try:
        candidate.relative_to(root)
        return True
    except ValueError:
        return False


def extract_zip_archive(zip_path: Path, extract_root: Path) -> tuple[list[Path], list[str], int]:
    file_paths: list[Path] = []
    dir_paths: set[str] = set()
    seen_files: set[str] = set()
    total_bytes = 0
    extract_root = extract_root.resolve()

    try:
        archive = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as error:
        raise FilesAutomationError("The selected file is not a valid ZIP archive.") from error

    with archive:
        members = archive.infolist()
        if not members:
            raise FilesAutomationError("The ZIP archive is empty.")

        for info in members:
            relative_path = zip_member_relative_path(info)
            if relative_path is None:
                continue

            relative_text = relative_path.as_posix()
            target_path = (extract_root / relative_path).resolve()
            if not path_is_within(extract_root, target_path):
                raise FilesAutomationError(f"ZIP member has an unsafe path: {info.filename}")

            if info.is_dir():
                target_path.mkdir(parents=True, exist_ok=True)
                dir_paths.add(relative_text.rstrip("/"))
                continue

            if info.flag_bits & 0x1:
                raise FilesAutomationError("Encrypted ZIP files are not supported.")

            file_key = os.path.normcase(str(relative_path))
            if file_key in seen_files:
                raise FilesAutomationError(f"ZIP archive contains duplicate file paths: {relative_text}")
            seen_files.add(file_key)

            total_bytes += max(0, int(info.file_size or 0))
            if total_bytes > FILES_EXTRACT_MAX_TOTAL_BYTES:
                raise FilesAutomationError("The ZIP archive is larger than the configured extract safety limit.")
            if len(file_paths) + 1 > FILES_EXTRACT_MAX_FILES:
                raise FilesAutomationError("The ZIP archive contains too many files to extract safely.")

            target_path.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target_path.open("wb") as target:
                shutil.copyfileobj(source, target, length=1024 * 1024)
            file_paths.append(target_path)

    return file_paths, sorted(dir_paths, key=lambda item: (item.count("/"), item.lower())), total_bytes


def default_extract_target_path(remote_path: str) -> str:
    source_path = normalize_remote_path(remote_path, allow_root=False)
    parent = remote_parent_path(source_path)
    name = remote_basename(source_path)
    stem = name[:-4] if name.lower().endswith(".zip") else f"{name}-extracted"
    stem = stem.strip() or "extracted"
    return remote_join(parent, normalize_remote_name(stem, "Extract folder name"))


class FilesRemoteClient:
    def __init__(self, username: str, password: str) -> None:
        self.username = str(username or "").strip()
        self.password = str(password or "")
        if not self.username or not self.password:
            raise FilesAutomationError("Sign in is required before managing cloud files.")
        self.session = requests.Session()
        self.csrf_token = ""
        self.last_action_at = 0.0

    def rate_guard(self, minimum: float = FILES_MIN_ACTION_INTERVAL) -> None:
        now = time.monotonic()
        wait_time = max(0.0, minimum - (now - self.last_action_at))
        if wait_time:
            time.sleep(wait_time)
        self.last_action_at = time.monotonic()

    @staticmethod
    def response_detail(response: requests.Response) -> str:
        text = response.text[:500].replace("\n", " ")
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        if isinstance(payload, dict):
            detail = str(payload.get("error") or payload.get("message") or "").strip()
            if detail:
                return detail[:500].replace("\n", " ")
        return text

    def request(
        self,
        method: str,
        url: str,
        label: str,
        expected: tuple[int, ...] = (200,),
        timeout: int = 60,
        **kwargs,
    ) -> requests.Response:
        body = kwargs.get("data")
        last_response: requests.Response | None = None
        for attempt in range(1, 5):
            self.rate_guard()
            if hasattr(body, "seek"):
                body.seek(0)
            response = self.session.request(method, url, timeout=timeout, **kwargs)
            last_response = response
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                wait_time = float(retry_after) if retry_after and retry_after.isdigit() else min(20, attempt * 3)
                time.sleep(wait_time)
                continue
            if response.status_code in expected:
                return response
            detail = self.response_detail(response)
            raise FilesAutomationError(f"{label} returned HTTP {response.status_code}: {detail}")

        status = last_response.status_code if last_response is not None else "no-response"
        raise FilesAutomationError(f"{label} failed after rate-limit retries; last status {status}.")

    def login(self) -> None:
        login_url = f"{FILES_BASE_URL}/web/client/login"
        response = self.request("GET", login_url, "load sign-in form")
        match = FORM_TOKEN_RE.search(response.text)
        if not match:
            raise FilesAutomationError("Could not find sign-in form token.")

        response = self.request(
            "POST",
            login_url,
            "sign in",
            expected=(301, 302, 303),
            data={"username": self.username, "password": self.password, "_form_token": match.group(1)},
            allow_redirects=False,
        )
        location = response.headers.get("Location", "")
        if "/web/client/files" not in location:
            raise PermissionError("Wrong username or password.")

        files_page = self.request("GET", FILES_SITE_URL, "load files page")
        csrf_match = CSRF_TOKEN_RE.search(files_page.text)
        if not csrf_match:
            raise FilesAutomationError("Could not find files CSRF token.")
        self.csrf_token = csrf_match.group(1)

    def csrf_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        headers = {"X-CSRF-TOKEN": self.csrf_token}
        headers.update(extra_headers or {})
        return headers

    def list_dir(self, remote_path: str) -> list[dict]:
        clean_path = normalize_remote_path(remote_path)
        response = self.request(
            "GET",
            f"{FILES_BASE_URL}/web/client/dirs?path={quote_remote_path(clean_path)}",
            f"list cloud path {clean_path}",
        )
        data = response.json()
        if not isinstance(data, list):
            raise FilesAutomationError("Cloud directory listing returned an invalid response.")
        return sort_cloud_entries([normalize_cloud_entry(clean_path, entry) for entry in data if isinstance(entry, dict)])

    def check_exists(self, parent_path: str, names: list[str]) -> list[dict]:
        response = self.request(
            "POST",
            f"{FILES_BASE_URL}/web/client/exist?op=upload&path={quote_remote_path(normalize_remote_path(parent_path))}",
            "check cloud destination",
            headers=self.csrf_headers({"Content-Type": "application/json"}),
            data=json.dumps({"files": names}),
        )
        data = response.json()
        return data if isinstance(data, list) else []

    def wait_task(self, task_id: str, label: str, timeout_seconds: int = 300) -> dict:
        clean_task_id = str(task_id or "").strip()
        if not clean_task_id:
            return {}

        deadline = time.monotonic() + timeout_seconds
        task_url = f"{FILES_BASE_URL}/web/client/tasks/{quote_remote_path(clean_task_id)}"
        while time.monotonic() < deadline:
            response = self.request(
                "GET",
                task_url,
                f"check {label} task",
                headers=self.csrf_headers(),
                timeout=30,
            )
            try:
                payload = response.json()
            except ValueError as error:
                raise FilesAutomationError(f"{label} task returned an invalid response.") from error
            task_status = int(payload.get("status", 0) or 0)
            if task_status == 200:
                return payload
            if task_status >= 400:
                raise FilesAutomationError(f"{label} task returned HTTP {task_status}.")
            time.sleep(max(0.1, FILES_TASK_POLL_INTERVAL))

        raise FilesAutomationError(f"{label} task did not finish in time.")

    def wait_task_response(self, response: requests.Response, label: str) -> dict:
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        task_id = str(payload.get("message", "") or "").strip() if isinstance(payload, dict) else ""
        return self.wait_task(task_id, label)

    def move(self, source_path: str, target_path: str) -> None:
        source = normalize_remote_path(source_path, allow_root=False)
        target = normalize_remote_path(target_path, allow_root=False)
        if source == target:
            raise ValueError("Source and destination are the same.")
        response = self.request(
            "POST",
            (
                f"{FILES_BASE_URL}/web/client/file-actions/move"
                f"?path={quote_remote_path(source)}&target={quote_remote_path(target)}"
            ),
            "move cloud item",
            expected=(202,),
            headers=self.csrf_headers(),
            timeout=30,
        )
        self.wait_task_response(response, "move")

    def delete(self, remote_path: str, item_type: str) -> None:
        clean_path = normalize_remote_path(remote_path, allow_root=False)
        if is_remote_dir_type(item_type):
            response = self.request(
                "DELETE",
                f"{FILES_BASE_URL}/web/client/dirs?path={quote_remote_path(clean_path)}",
                "delete cloud folder",
                expected=(202, 404),
                headers=self.csrf_headers(),
                timeout=30,
            )
            if response.status_code == 404:
                return
            self.wait_task_response(response, "delete")
            return

        self.request(
            "DELETE",
            f"{FILES_BASE_URL}/web/client/files?path={quote_remote_path(clean_path)}",
            "delete cloud file",
            expected=(200, 404),
            headers=self.csrf_headers(),
            timeout=30,
        )

    def create_dir(self, remote_path: str, parents: bool = True, ignore_existing: bool = False) -> None:
        clean_path = normalize_remote_path(remote_path, allow_root=False)
        query = f"path={quote_remote_path(clean_path)}"
        if parents:
            query += "&mkdir_parents=true"
        response = self.request(
            "POST",
            f"{FILES_BASE_URL}/web/client/dirs?{query}",
            "create cloud folder",
            expected=(201, 409),
            headers=self.csrf_headers(),
            timeout=30,
        )
        if response.status_code == 409 and not ignore_existing:
            raise FilesAutomationError(f"Cloud folder already exists: {clean_path}")

    def download_file(self, remote_path: str, destination: Path, max_bytes: int = FILES_EXTRACT_MAX_ZIP_BYTES) -> int:
        clean_path = normalize_remote_path(remote_path, allow_root=False)
        total_bytes = 0
        url = f"{FILES_BASE_URL}/web/client/file?path={quote_remote_path(clean_path)}"
        last_status: int | str = "no-response"
        for attempt in range(1, 5):
            self.rate_guard()
            response = self.session.get(url, headers=self.csrf_headers(), timeout=300, stream=True)
            last_status = response.status_code
            if response.status_code == 429:
                response.close()
                retry_after = response.headers.get("Retry-After")
                wait_time = float(retry_after) if retry_after and retry_after.isdigit() else min(20, attempt * 3)
                time.sleep(wait_time)
                continue
            if response.status_code != 200:
                detail = self.response_detail(response)
                response.close()
                raise FilesAutomationError(f"download ZIP returned HTTP {response.status_code}: {detail}")

            with response, destination.open("wb") as target:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if not chunk:
                        continue
                    total_bytes += len(chunk)
                    if total_bytes > max_bytes:
                        raise FilesAutomationError("The ZIP file is larger than the configured extract safety limit.")
                    target.write(chunk)
            return total_bytes

        raise FilesAutomationError(f"download ZIP failed after rate-limit retries; last status {last_status}.")

    def upload_file(self, local_path: Path, remote_path: str) -> None:
        clean_remote_path = normalize_remote_path(remote_path, allow_root=False)
        headers = self.csrf_headers(
            {
                "X-SFTPGO-MTIME": str(round(local_path.stat().st_mtime * 1000)),
                "Content-Type": "application/octet-stream",
            }
        )
        with local_path.open("rb") as handle:
            self.request(
                "POST",
                f"{FILES_BASE_URL}/web/client/file?path={quote_remote_path(clean_remote_path)}&mkdir_parents=true",
                f"upload extracted file {clean_remote_path}",
                expected=(201,),
                headers=headers,
                data=handle,
                timeout=300,
            )

    def extract_remote_zip(self, remote_path: str, target_path: str = "") -> dict:
        source = normalize_remote_path(remote_path, allow_root=False)
        if not remote_basename(source).lower().endswith(".zip"):
            raise ValueError("Only ZIP files can be extracted.")

        target = normalize_remote_path(target_path, "Extract target", allow_root=False) if target_path else default_extract_target_path(source)
        target_parent = remote_parent_path(target)
        target_name = normalize_remote_name(remote_basename(target), "Extract target folder name")
        target = remote_join(target_parent, target_name)

        if self.check_exists(target_parent, [target_name]):
            raise FilesAutomationError(f"The extract target already exists: {target}")

        with tempfile.TemporaryDirectory(prefix="6ure-files-extract-") as temp_dir:
            temp_root = Path(temp_dir)
            archive_path = temp_root / "archive.zip"
            extract_root = temp_root / "contents"
            extract_root.mkdir(parents=True, exist_ok=True)

            downloaded_bytes = self.download_file(source, archive_path)
            file_paths, dir_paths, total_bytes = extract_zip_archive(archive_path, extract_root)

            self.create_dir(target, parents=True)
            for relative_dir in dir_paths:
                self.create_dir(remote_join(target, relative_dir), parents=True, ignore_existing=True)

            for local_file in file_paths:
                relative_path = local_file.relative_to(extract_root).as_posix()
                self.upload_file(local_file, remote_join(target, relative_path))

        return {
            "path": target,
            "files": len(file_paths),
            "folders": len(dir_paths),
            "sizeBytes": total_bytes,
            "downloadedBytes": downloaded_bytes,
        }


def get_authenticated_remote_client() -> FilesRemoteClient:
    username, password = get_session_credentials()
    if not username or not password:
        sync_session_from_state()
        username, password = get_session_credentials()
    if not username or not password:
        raise FilesAutomationError("Sign in is required before managing cloud files.")

    now = time.monotonic()
    with REMOTE_CLIENT_LOCK:
        cached_client = REMOTE_CLIENT_CACHE.get("client")
        if (
            cached_client is not None
            and REMOTE_CLIENT_CACHE.get("username") == username
            and REMOTE_CLIENT_CACHE.get("password") == password
            and float(REMOTE_CLIENT_CACHE.get("expiresAt") or 0.0) > now
        ):
            REMOTE_CLIENT_CACHE["expiresAt"] = now + REMOTE_CLIENT_TTL_SECONDS
            return cached_client

    client = FilesRemoteClient(username, password)
    client.login()
    with REMOTE_CLIENT_LOCK:
        stale_client = REMOTE_CLIENT_CACHE.get("client")
        stale_session = getattr(stale_client, "session", None)
        if stale_session is not None:
            try:
                stale_session.close()
            except Exception:
                pass
        REMOTE_CLIENT_CACHE["username"] = username
        REMOTE_CLIENT_CACHE["password"] = password
        REMOTE_CLIENT_CACHE["client"] = client
        REMOTE_CLIENT_CACHE["expiresAt"] = time.monotonic() + REMOTE_CLIENT_TTL_SECONDS
    return client


class CancellableFileReader:
    def __init__(self, handle, cancel_event: threading.Event) -> None:
        self._handle = handle
        self._cancel_event = cancel_event
        self.name = getattr(handle, "name", "")
        self.mode = getattr(handle, "mode", "rb")

    def _check_cancelled(self) -> None:
        if self._cancel_event.is_set():
            raise FilesUploadCancelledError()

    def read(self, size: int = -1):
        self._check_cancelled()
        chunk = self._handle.read(size)
        self._check_cancelled()
        return chunk

    def seek(self, offset: int, whence: int = os.SEEK_SET):
        return self._handle.seek(offset, whence)

    def tell(self) -> int:
        return self._handle.tell()

    def fileno(self) -> int:
        return self._handle.fileno()


def normalize_local_folder_paths(folder_paths) -> list[Path]:
    if isinstance(folder_paths, (str, Path)):
        candidates = [folder_paths]
    elif isinstance(folder_paths, list):
        candidates = folder_paths
    else:
        candidates = []

    resolved_paths: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        text = str(candidate or "").strip()
        if not text:
            continue
        path = Path(text).expanduser().resolve()
        if not path.is_dir():
            raise ValueError(f"Selected leak folder does not exist: {path}")
        key = os.path.normcase(str(path))
        if key in seen:
            continue
        seen.add(key)
        resolved_paths.append(path)

    if not resolved_paths:
        raise ValueError("At least one leak folder is required.")

    return resolved_paths


def get_local_folder_summary(folder_path: Path) -> dict:
    total_bytes = 0
    file_count = 0
    for item in folder_path.rglob("*"):
        try:
            if not item.is_file():
                continue
            file_count += 1
            total_bytes += item.stat().st_size
        except OSError:
            continue

    return {
        "path": str(folder_path),
        "name": folder_path.name,
        "sizeBytes": total_bytes,
        "fileCount": file_count,
    }


def get_local_folder_summaries(folder_paths) -> list[dict]:
    return [get_local_folder_summary(path) for path in normalize_local_folder_paths(folder_paths)]


def save_last_folder_selection(paths: list[Path]) -> dict:
    if not paths:
        return clear_last_files_selection()
    return save_files_state(
        lastFolderPath=str(paths[0]),
        lastFolderName=paths[0].name,
        lastFolderPaths=[str(path) for path in paths],
        lastFolderNames=[path.name for path in paths],
    )


def validate_files_credentials(username: str, password: str) -> None:
    username = str(username or "").strip()
    password = str(password or "")
    if not username or not password:
        raise ValueError("Username and password are required.")

    session = requests.Session()
    response = session.get(f"{FILES_BASE_URL}/web/client/login", timeout=30)
    if response.status_code != 200:
        raise FilesAutomationError(f"Sign-in page returned HTTP {response.status_code}.")

    match = FORM_TOKEN_RE.search(response.text)
    if not match:
        raise FilesAutomationError("Could not find sign-in form token.")

    response = session.post(
        f"{FILES_BASE_URL}/web/client/login",
        timeout=30,
        data={"username": username, "password": password, "_form_token": match.group(1)},
        allow_redirects=False,
    )
    location = response.headers.get("Location", "")
    if response.status_code not in {301, 302, 303} or "/web/client/files" not in location:
        raise PermissionError("Wrong username or password.")

    files_page = session.get(FILES_SITE_URL, timeout=30)
    if files_page.status_code != 200:
        raise FilesAutomationError(f"Files page returned HTTP {files_page.status_code}.")
    if not CSRF_TOKEN_RE.search(files_page.text):
        raise FilesAutomationError("Could not verify the files session.")


class FilesUploadJob:
    def __init__(self, editor_name: str, folder_paths) -> None:
        self.id = uuid.uuid4().hex
        self.editor_name = normalize_remote_name(editor_name, "Editor name")
        self.folder_paths = normalize_local_folder_paths(folder_paths)
        self.folder_names: list[str] = []
        seen_folder_names: set[str] = set()
        for path in self.folder_paths:
            folder_name = normalize_remote_name(path.name, "Leak folder name")
            folder_key = folder_name.lower()
            if folder_key in seen_folder_names:
                raise ValueError("Selected leak folders must have unique folder names.")
            seen_folder_names.add(folder_key)
            self.folder_names.append(folder_name)

        self.folder_path = self.folder_paths[0]
        self.folder_name = self.folder_names[0]
        self.folder_count = len(self.folder_paths)
        self.created_at = int(time.time() * 1000)
        self.status = "queued"
        self.phase = "Queued"
        self.progress = 0
        self.total_files = 0
        self.uploaded_files = 0
        self.logs: list[str] = []
        self.technical_report = ""
        self.result_kind = ""
        self.result_paths: list[str] = []
        self.duplicate_path = ""
        self.protected_matches: list[dict] = []
        self.protected_warning = ""
        self.last_action_at = 0.0
        self.last_presence_at = 0.0
        self.last_presence_phase = ""
        self.last_presence_progress = -1
        self.last_presence_status = ""
        self.cancel_event = threading.Event()
        self.cancel_requested = False
        self.rollback_targets: list[str] = []
        self.rollback_errors: list[str] = []
        self.lock = threading.Lock()

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "id": self.id,
                "status": self.status,
                "phase": self.phase,
                "progress": self.progress,
                "totalFiles": self.total_files,
                "uploadedFiles": self.uploaded_files,
                "editorName": self.editor_name,
                "folderName": self.folder_name,
                "folderNames": list(self.folder_names),
                "folderCount": self.folder_count,
                "logs": self.logs[-80:],
                "technicalReport": self.technical_report,
                "resultKind": self.result_kind,
                "resultPaths": list(self.result_paths),
                "duplicatePath": self.duplicate_path,
                "protectedMatches": list(self.protected_matches),
                "protectedWarning": self.protected_warning,
                "cancelRequested": self.cancel_requested,
                "rollbackErrors": list(self.rollback_errors),
            }

    def set_status(self, status: str, phase: str | None = None) -> None:
        with self.lock:
            if self.cancel_requested and status in {"queued", "running"}:
                self.status = "cancelling"
                if phase:
                    self.phase = phase if phase == "Rolling back" else "Cancelling"
                presence_changed = True
            else:
                self.status = status
                if phase:
                    self.phase = phase
                presence_changed = True
        if presence_changed:
            self.update_presence(force=True)

    def set_progress(self) -> None:
        with self.lock:
            self.progress = 0 if not self.total_files else round((self.uploaded_files / self.total_files) * 100)
        self.update_presence()

    def log(self, message: str) -> None:
        timestamp = time.strftime("%H:%M:%S")
        with self.lock:
            self.logs.append(f"{timestamp} - {message}")
            self.logs = self.logs[-160:]

    def update_presence(self, force: bool = False) -> None:
        with self.lock:
            status = self.status
            phase = self.phase
            progress = self.progress
            uploaded_files = self.uploaded_files
            total_files = self.total_files
            now = time.monotonic()
            if not force:
                progress_step = progress >= self.last_presence_progress + 5
                phase_changed = phase != self.last_presence_phase or status != self.last_presence_status
                time_elapsed = now - self.last_presence_at >= 5.0
                if not phase_changed and not progress_step and not time_elapsed:
                    return
            self.last_presence_at = now
            self.last_presence_phase = phase
            self.last_presence_progress = progress
            self.last_presence_status = status

        if status in {"queued", "running"}:
            if phase == "Uploading":
                details = f"Leaking: {self.editor_name}"
                state = f"Uploading files - {progress}%"
                if total_files:
                    state = f"{state} ({uploaded_files}/{total_files})"
                set_discord_presence_activity(details=details, state=state)
                return
            set_discord_presence_activity(details="Preparing upload", state=phase or "Queued")
            return

        if status == "cancelling":
            set_discord_presence_activity(details="Cancelling upload", state=phase or "Rolling back")
            return
        if status == "success":
            set_discord_presence_activity(details="Upload complete", state="Ready to upload")
            return
        if status == "cancelled":
            set_discord_presence_activity(details="Upload cancelled", state="Ready to upload")
            return
        if status == "failed":
            set_discord_presence_activity(details="Upload failed", state="Needs attention")

    def set_protected_warning(self, matches: list[dict], warning: str = "") -> None:
        clean_matches = [match for match in matches if isinstance(match, dict)]
        message = warning or protected_publish_warning(clean_matches)
        with self.lock:
            self.protected_matches = clean_matches
            self.protected_warning = message

    def request_cancel(self) -> None:
        with self.lock:
            if self.status in {"success", "failed", "cancelled"}:
                return
            self.cancel_requested = True
            self.status = "cancelling"
            self.phase = "Cancelling"
        self.cancel_event.set()
        self.log("Cancel requested. Rolling back this upload job.")
        self.update_presence(force=True)

    def ensure_not_cancelled(self) -> None:
        if self.cancel_event.is_set():
            raise FilesUploadCancelledError()

    def add_rollback_target(self, editor_name: str, folder_name: str) -> None:
        remote_path = "/" + "/".join(part.strip("/") for part in (editor_name, folder_name) if part)
        with self.lock:
            if remote_path not in self.rollback_targets:
                self.rollback_targets.append(remote_path)

    def fail(self, error: Exception) -> None:
        remote_folders = "\n".join(f"- /{self.editor_name}/{name}" for name in self.folder_names)
        local_folders = "\n".join(f"- {path}" for path in self.folder_paths)
        duplicate_path = error.remote_path if isinstance(error, FilesDuplicateLeakError) else ""
        protected_matches = error.matches if isinstance(error, FilesProtectedNameError) else []
        protected_report = (
            "\n".join(
                f"- {item.get('candidateName')} matched {item.get('protectedName')} via {item.get('matchedAlias')}"
                for item in protected_matches
            )
            if protected_matches
            else ""
        )
        with self.lock:
            self.status = "failed"
            self.phase = "Failed"
            self.result_kind = "duplicate" if duplicate_path else "protected" if protected_matches else "failed"
            self.duplicate_path = duplicate_path
            self.result_paths = (
                [duplicate_path]
                if duplicate_path
                else [
                    f"{item.get('candidateName')} -> {item.get('protectedName')}"
                    for item in protected_matches
                    if item.get("candidateName") and item.get("protectedName")
                ]
            )
            self.technical_report = (
                f"error_type: {type(error).__name__}\n"
                f"message: {error}\n"
                f"editor: {self.editor_name}\n"
                f"local_folders:\n{local_folders}\n"
                f"remote_folders:\n{remote_folders}\n"
                + (f"protected_matches:\n{protected_report}\n" if protected_report else "")
                + f"uploaded_files: {self.uploaded_files}/{self.total_files}\n"
            )
        self.update_presence(force=True)

    def mark_cancelled(self, rollback_errors: list[str]) -> None:
        remote_folders = "\n".join(f"- /{self.editor_name}/{name}" for name in self.folder_names)
        local_folders = "\n".join(f"- {path}" for path in self.folder_paths)
        with self.lock:
            self.rollback_errors = list(rollback_errors)
            if rollback_errors:
                self.status = "failed"
                self.phase = "Rollback failed"
                self.result_kind = "cancel_failed"
                self.technical_report = (
                    "Upload cancellation was requested, but rollback did not complete cleanly.\n"
                    f"editor: {self.editor_name}\n"
                    f"local_folders:\n{local_folders}\n"
                    f"remote_folders:\n{remote_folders}\n"
                    "rollback_errors:\n"
                    + "\n".join(f"- {error}" for error in rollback_errors)
                    + "\n"
                )
            else:
                self.status = "cancelled"
                self.phase = "Cancelled"
                self.result_kind = "cancelled"
                self.technical_report = ""
            self.result_paths = []
            self.duplicate_path = ""
        self.update_presence(force=True)

    def rate_guard(
        self,
        label: str,
        minimum: float = FILES_MIN_ACTION_INTERVAL,
        ignore_cancel: bool = False,
    ) -> None:
        now = time.monotonic()
        wait_time = max(0.0, minimum - (now - self.last_action_at))
        deadline = now + wait_time
        while time.monotonic() < deadline:
            if not ignore_cancel:
                self.ensure_not_cancelled()
            time.sleep(min(0.1, max(0.0, deadline - time.monotonic())))
        self.last_action_at = time.monotonic()

    def request(
        self,
        session: requests.Session,
        method: str,
        url: str,
        label: str,
        expected: tuple[int, ...] = (200,),
        ignore_cancel: bool = False,
        **kwargs,
    ) -> requests.Response:
        last_response: requests.Response | None = None
        timeout = kwargs.pop("timeout", 60)
        body = kwargs.get("data")
        for attempt in range(1, 5):
            if not ignore_cancel:
                self.ensure_not_cancelled()
            self.rate_guard(label, ignore_cancel=ignore_cancel)
            if hasattr(body, "seek"):
                body.seek(0)
            try:
                response = session.request(method, url, timeout=timeout, **kwargs)
            except Exception as error:
                if not ignore_cancel and self.cancel_event.is_set():
                    raise FilesUploadCancelledError() from error
                raise
            last_response = response
            if not ignore_cancel:
                self.ensure_not_cancelled()
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                wait_time = float(retry_after) if retry_after and retry_after.isdigit() else min(20, attempt * 3)
                self.log(f"Rate limited during {label}; backing off for {wait_time:.0f}s.")
                deadline = time.monotonic() + wait_time
                while time.monotonic() < deadline:
                    if not ignore_cancel:
                        self.ensure_not_cancelled()
                    time.sleep(min(0.2, max(0.0, deadline - time.monotonic())))
                continue
            if response.status_code in expected:
                return response
            detail = response.text[:500].replace("\n", " ")
            raise FilesAutomationError(f"{label} returned HTTP {response.status_code}: {detail}")

        status = last_response.status_code if last_response is not None else "no-response"
        raise FilesAutomationError(f"{label} failed after rate-limit retries; last status {status}.")

    def run(self) -> None:
        session: requests.Session | None = None
        csrf_token = ""
        try:
            self.ensure_not_cancelled()
            self.set_status("running", "Preparing")
            username, password = get_session_credentials()
            if not username or not password:
                sync_session_from_state()
                username, password = get_session_credentials()
            if not username or not password:
                raise FilesAutomationError("Sign in is required before starting an upload.")
            self.ensure_not_cancelled()

            folder_payloads: list[tuple[Path, str, list[Path]]] = []
            empty_folders: list[str] = []
            total_bytes = 0
            total_files = 0
            for folder_path, folder_name in zip(self.folder_paths, self.folder_names):
                self.ensure_not_cancelled()
                files = [path for path in folder_path.rglob("*") if path.is_file()]
                if not files:
                    empty_folders.append(folder_name)
                    continue
                folder_payloads.append((folder_path, folder_name, files))
                total_bytes += sum(path.stat().st_size for path in files)
                total_files += len(files)

            if empty_folders:
                raise FilesAutomationError(
                    "Selected leak folders do not contain uploadable files: " + ", ".join(empty_folders)
                )
            if not folder_payloads:
                raise FilesAutomationError("Selected leak folders do not contain uploadable files.")
            if total_bytes > FILES_MAX_UPLOAD_BYTES:
                raise FilesAutomationError("Selected leak folders are larger than the configured upload safety limit.")

            self.total_files = total_files
            self.set_progress()
            self.log(f"Queued {self.total_files} files from {self.folder_count} leak folders.")
            self.set_status("running", "Checking protected list")
            try:
                protected_result = check_protected_names([self.editor_name, *self.folder_names])
                self.log(f"Checked {protected_result['protectedCount']} protected names from 6ureleaks.com.")
                if protected_result["matches"]:
                    self.set_protected_warning(protected_result["matches"])
                    self.log(self.protected_warning)
            except FilesAutomationError as error:
                self.set_protected_warning(
                    [],
                    "The protected list could not be checked live. The upload will continue, but publishing should be reviewed before posting to 6ureleaks.com/resources.",
                )
                self.log(f"Protected list check warning: {error}")

            session = requests.Session()
            csrf_token = self.login(session, username, password)
            self.ensure_not_cancelled()
            editor_remote_name = self.ensure_editor_folder(session, csrf_token)
            result_paths: list[str] = []
            for folder_path, folder_name, files in folder_payloads:
                self.ensure_not_cancelled()
                self.ensure_upload_target_is_clear(session, csrf_token, editor_remote_name, folder_name)
                self.add_rollback_target(editor_remote_name, folder_name)
                self.upload_folder(session, csrf_token, editor_remote_name, folder_path, folder_name, files)
                self.ensure_not_cancelled()
                self.verify_uploaded_folder(session, editor_remote_name, folder_name)
                result_paths.append(f"{editor_remote_name}/{folder_name}")

            self.ensure_not_cancelled()
            record_upload_batch_history(editor_name=editor_remote_name, folder_paths=self.folder_paths)
            clear_last_files_selection()
            self.set_status("success", "Complete")
            with self.lock:
                self.progress = 100
                self.result_kind = "protected_warning" if self.protected_warning else "success"
                self.result_paths = result_paths
            self.duplicate_path = ""
            self.update_presence(force=True)
            if self.protected_warning:
                self.log("Upload complete. Publishing warning remains active.")
            else:
                self.log("Upload complete. Run /cloud moveall in Discord.")
        except FilesUploadCancelledError:
            self.log("Cancellation started. Removing files uploaded by this job.")
            rollback_errors: list[str] = []
            if session is not None and csrf_token:
                rollback_errors = self.rollback_upload(session, csrf_token)
            else:
                self.log("Nothing was uploaded before cancellation.")
            self.mark_cancelled(rollback_errors)
            if rollback_errors:
                self.log("Cancellation finished, but rollback reported errors.")
            else:
                self.log("Upload cancelled and rolled back.")
        except Exception as error:
            self.log(f"Failed: {error}")
            self.fail(error)

    def login(self, session: requests.Session, username: str, password: str) -> str:
        self.set_status("running", "Signing in")
        login_url = f"{FILES_BASE_URL}/web/client/login"
        response = self.request(session, "GET", login_url, "load sign-in form")
        match = FORM_TOKEN_RE.search(response.text)
        if not match:
            raise FilesAutomationError("Could not find sign-in form token.")

        response = self.request(
            session,
            "POST",
            login_url,
            "sign in",
            expected=(302,),
            data={"username": username, "password": password, "_form_token": match.group(1)},
            allow_redirects=False,
        )
        location = response.headers.get("Location", "")
        if "/web/client/files" not in location:
            raise FilesAutomationError("Sign-in did not redirect to the files page.")

        files_page = self.request(session, "GET", FILES_SITE_URL, "load files page")
        csrf_match = CSRF_TOKEN_RE.search(files_page.text)
        if not csrf_match:
            raise FilesAutomationError("Could not find files CSRF token.")
        self.log("Authenticated with files.6ureleaks.com.")
        return csrf_match.group(1)

    def list_dirs(
        self,
        session: requests.Session,
        path: str,
        label: str,
        ignore_cancel: bool = False,
    ) -> list[dict]:
        response = self.request(
            session,
            "GET",
            f"{FILES_BASE_URL}/web/client/dirs?path={quote_remote_path(path)}",
            label,
            ignore_cancel=ignore_cancel,
        )
        data = response.json()
        return data if isinstance(data, list) else []

    def ensure_editor_folder(self, session: requests.Session, csrf_token: str) -> str:
        self.set_status("running", "Scanning editors")
        root_entries = self.list_dirs(session, "/", "scan all editor folders")
        self.log(f"Scanned {len(root_entries)} root folders across the full editor list.")
        folders = [entry for entry in root_entries if str(entry.get("type")) == "1"]
        existing = next((entry.get("name") for entry in folders if str(entry.get("name", "")).lower() == self.editor_name.lower()), None)
        if existing:
            self.log(f"Editor folder found: {existing}.")
            return str(existing)

        self.set_status("running", "Creating editor folder")
        self.request(
            session,
            "POST",
            f"{FILES_BASE_URL}/web/client/dirs?path={quote_remote_path('/' + self.editor_name)}",
            "create editor folder",
            expected=(201,),
            headers={"X-CSRF-TOKEN": csrf_token},
        )
        self.log(f"Editor folder created: {self.editor_name}.")
        return self.editor_name

    def ensure_upload_target_is_clear(
        self,
        session: requests.Session,
        csrf_token: str,
        editor_name: str,
        folder_name: str,
    ) -> None:
        self.set_status("running", "Checking destination")
        response = self.request(
            session,
            "POST",
            f"{FILES_BASE_URL}/web/client/exist?op=upload&path={quote_remote_path('/' + editor_name)}",
            "check upload target",
            headers={"X-CSRF-TOKEN": csrf_token, "Content-Type": "application/json"},
            data=json.dumps({"files": [folder_name]}),
        )
        existing = response.json()
        if existing:
            raise FilesDuplicateLeakError(f"{editor_name}/{folder_name}")
        self.log(f"Destination is clear for {folder_name}.")

    def upload_folder(
        self,
        session: requests.Session,
        csrf_token: str,
        editor_name: str,
        folder_path: Path,
        folder_name: str,
        files: list[Path],
    ) -> None:
        self.set_status("running", "Uploading")
        checked_dirs: set[str] = set()
        remote_root = "/" + editor_name
        for file_path in files:
            self.ensure_not_cancelled()
            relative = file_path.relative_to(folder_path).as_posix()
            upload_name = f"{folder_name}/{relative}"
            parent = upload_name.rsplit("/", 1)[0]
            mkdir_parents = "false"
            if parent not in checked_dirs:
                mkdir_parents = "true"
                checked_dirs.add(parent)

            upload_url = (
                f"{FILES_BASE_URL}/web/client/file?path={quote_remote_path(remote_root)}"
                f"{quote_remote_path('/' + upload_name)}&mkdir_parents={mkdir_parents}"
            )
            headers = {
                "X-CSRF-TOKEN": csrf_token,
                "X-SFTPGO-MTIME": str(round(file_path.stat().st_mtime * 1000)),
                "Content-Type": "application/octet-stream",
            }
            self.log(f"Uploading {upload_name}.")
            with file_path.open("rb") as handle:
                self.request(
                    session,
                    "POST",
                    upload_url,
                    f"upload {upload_name}",
                    expected=(201,),
                    headers=headers,
                    data=CancellableFileReader(handle, self.cancel_event),
                    timeout=300,
                )
            self.ensure_not_cancelled()
            with self.lock:
                self.uploaded_files += 1
            self.set_progress()

    def verify_uploaded_folder(self, session: requests.Session, editor_name: str, folder_name: str) -> None:
        self.set_status("running", "Verifying")
        deadline = time.monotonic() + 25
        while time.monotonic() < deadline:
            self.ensure_not_cancelled()
            entries = self.list_dirs(session, "/" + editor_name, "verify uploaded folder")
            if any(str(entry.get("type")) == "1" and entry.get("name") == folder_name for entry in entries):
                self.log(f"Verified folder on screen/list: /{editor_name}/{folder_name}.")
                return
            sleep_deadline = time.monotonic() + 1.5
            while time.monotonic() < sleep_deadline:
                self.ensure_not_cancelled()
                time.sleep(min(0.2, max(0.0, sleep_deadline - time.monotonic())))
        raise FilesAutomationError("Upload finished but the remote folder was not visible during verification.")

    def rollback_upload(self, session: requests.Session, csrf_token: str) -> list[str]:
        with self.lock:
            targets = list(reversed(self.rollback_targets))
        if not targets:
            self.log("Nothing was uploaded before cancellation.")
            return []

        self.set_status("running", "Rolling back")
        rollback_errors: list[str] = []
        for remote_path in targets:
            try:
                self.delete_remote_folder(session, csrf_token, remote_path)
                self.log(f"Rolled back {remote_path}.")
            except Exception as error:
                message = f"{remote_path}: {error}"
                rollback_errors.append(message)
                self.log(f"Rollback error: {message}")
        return rollback_errors

    def delete_remote_folder(self, session: requests.Session, csrf_token: str, remote_path: str) -> None:
        clean_remote_path = normalize_remote_path(remote_path, allow_root=False)
        response = self.request(
            session,
            "DELETE",
            f"{FILES_BASE_URL}/web/client/dirs?path={quote_remote_path(clean_remote_path)}",
            f"delete remote folder {clean_remote_path}",
            expected=(202, 404),
            headers={"X-CSRF-TOKEN": csrf_token},
            timeout=30,
            ignore_cancel=True,
        )
        if response.status_code == 404:
            self.log(f"Remote folder was already absent: {clean_remote_path}.")
            return

        try:
            payload = response.json()
        except ValueError:
            payload = {}
        task_id = str(payload.get("message", "") or "").strip()
        if not task_id:
            self.wait_remote_folder_absent(session, clean_remote_path, timeout_seconds=60)
            return

        deadline = time.monotonic() + 300
        task_url = f"{FILES_BASE_URL}/web/client/tasks/{quote_remote_path(task_id)}"
        try:
            while time.monotonic() < deadline:
                task_response = self.request(
                    session,
                    "GET",
                    task_url,
                    f"check delete task {task_id}",
                    expected=(200,),
                    headers={"X-CSRF-TOKEN": csrf_token},
                    timeout=30,
                    ignore_cancel=True,
                )
                try:
                    task_payload = task_response.json()
                except ValueError as error:
                    raise FilesAutomationError("Delete task returned an invalid response.") from error
                task_status = int(task_payload.get("status", 0) or 0)
                if task_status == 200:
                    return
                if task_status >= 400:
                    raise FilesAutomationError(f"Delete task returned HTTP {task_status}.")
                time.sleep(1)
        except FilesAutomationError as error:
            message = str(error).lower()
            if "returned http 401" not in message and "returned http 403" not in message and "invalid token" not in message:
                raise
            self.log("Delete task status could not be read. Verifying folder removal from the cloud list.")
            self.wait_remote_folder_absent(session, clean_remote_path, timeout_seconds=300)
            return

        self.log("Delete task did not finish in time. Verifying folder removal from the cloud list.")
        self.wait_remote_folder_absent(session, clean_remote_path, timeout_seconds=120)

    def remote_folder_exists(self, session: requests.Session, remote_path: str) -> bool:
        clean_path = normalize_remote_path(remote_path, allow_root=False)
        parent = remote_parent_path(clean_path)
        name = remote_basename(clean_path)
        entries = self.list_dirs(session, parent, f"check rollback target {clean_path}", ignore_cancel=True)
        return any(str(entry.get("type")) == "1" and str(entry.get("name", "")) == name for entry in entries)

    def wait_remote_folder_absent(
        self,
        session: requests.Session,
        remote_path: str,
        timeout_seconds: int = 180,
    ) -> None:
        clean_path = normalize_remote_path(remote_path, allow_root=False)
        deadline = time.monotonic() + timeout_seconds
        last_error = ""
        while time.monotonic() < deadline:
            try:
                if not self.remote_folder_exists(session, clean_path):
                    self.log(f"Verified remote folder is absent: {clean_path}.")
                    return
            except Exception as error:
                last_error = str(error)
            time.sleep(1.2)
        suffix = f" Last check: {last_error}" if last_error else ""
        raise FilesAutomationError(f"Delete was accepted, but {clean_path} was still visible after waiting.{suffix}")


def start_files_job(editor_name: str, folder_paths) -> FilesUploadJob:
    job = FilesUploadJob(editor_name, folder_paths)
    with FILES_JOBS_LOCK:
        FILES_JOBS[job.id] = job
    threading.Thread(target=job.run, daemon=True).start()
    return job


class FilesAppHandler(BaseHTTPRequestHandler):
    server_version = "6ureFilesLocal/1.0"

    def _send(
        self,
        status: int,
        body: bytes,
        content_type: str = "application/json; charset=utf-8",
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, status: int, payload: dict) -> None:
        self._send(status, json_bytes(payload))

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_BODY_BYTES:
            raise ValueError("Request body is too large.")
        raw = self.rfile.read(length).decode("utf-8") if length else "{}"
        return json.loads(raw or "{}")

    def do_OPTIONS(self) -> None:
        self._send(204, b"", "text/plain; charset=utf-8")

    def do_GET(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path == "/health":
            self._send_json(200, {"ok": True})
            return
        if parsed.path == "/api/files/last":
            self._files_last()
            return
        if parsed.path == "/api/files/status":
            self._files_status(parsed.query)
            return
        if parsed.path == "/api/cloud/list":
            self._cloud_list(parsed.query)
            return
        if parsed.path == "/api/protected/list":
            self._protected_list()
            return
        if parsed.path == "/api/update/status":
            self._update_status()
            return
        if parsed.path == "/api/discord-presence/status":
            self._discord_presence_status()
            return
        if parsed.path == "/api/network/status":
            self._network_status()
            return
        if parsed.path == "/api/leaker-mode/status":
            self._leaker_mode_status()
            return
        if parsed.path == "/api/leaker-oauth/status":
            self._leaker_oauth_status()
            return
        if parsed.path == LEAKER_OAUTH_BRIDGE_PATH:
            self._leaker_oauth_bridge(parsed.query)
            return
        if is_leaker_site_root_request(parsed, self.headers) or is_leaker_proxy_path(parsed.path):
            self._leaker_proxy(parsed)
            return
        self._serve_static(parsed.path)

    def do_HEAD(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        if is_leaker_site_root_request(parsed, self.headers) or is_leaker_proxy_path(parsed.path):
            self._leaker_proxy(parsed)
            return
        self._send(404, b"", "text/plain; charset=utf-8")

    def do_POST(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path == "/api/window-action":
            self._window_action()
            return
        if parsed.path == "/api/open-url":
            self._open_url()
            return
        if parsed.path == "/api/leaker-mode/start":
            self._leaker_mode_start()
            return
        if parsed.path == "/api/leaker-mode/launch":
            self._leaker_mode_launch()
            return
        if parsed.path == "/api/leaker-mode/exit":
            self._leaker_mode_exit()
            return
        if parsed.path == "/api/leaker-oauth/open":
            self._leaker_oauth_open()
            return
        if parsed.path == "/api/files/login":
            self._files_login()
            return
        if parsed.path == "/api/files/logout":
            self._files_logout()
            return
        if parsed.path == "/api/files/select-folder":
            self._files_select_folder()
            return
        if parsed.path == "/api/files/folder-summary":
            self._files_folder_summary()
            return
        if parsed.path == "/api/files/start-upload":
            self._files_start_upload()
            return
        if parsed.path == "/api/files/cancel-upload":
            self._files_cancel_upload()
            return
        if parsed.path == "/api/cloud/action":
            self._cloud_action()
            return
        if parsed.path == "/api/protected/check":
            self._protected_check()
            return
        if parsed.path == "/api/update/check":
            self._update_check()
            return
        if parsed.path == "/api/update/install":
            self._update_install()
            return
        if parsed.path == "/api/discord-presence/activity":
            self._discord_presence_activity()
            return
        if parsed.path == "/api/discord-presence/clear":
            self._discord_presence_clear()
            return
        if is_leaker_proxy_path(parsed.path):
            self._leaker_proxy(parsed)
            return
        self._send_json(404, {"success": False, "msg": "Not found."})

    def do_PUT(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        if is_leaker_proxy_path(parsed.path):
            self._leaker_proxy(parsed)
            return
        self._send_json(404, {"success": False, "msg": "Not found."})

    def do_PATCH(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        if is_leaker_proxy_path(parsed.path):
            self._leaker_proxy(parsed)
            return
        self._send_json(404, {"success": False, "msg": "Not found."})

    def do_DELETE(self) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        if is_leaker_proxy_path(parsed.path):
            self._leaker_proxy(parsed)
            return
        self._send_json(404, {"success": False, "msg": "Not found."})

    def _serve_static(self, request_path: str) -> None:
        target = "index.html" if request_path in ("", "/") else request_path.lstrip("/")
        file_path = (ROOT / target).resolve()

        if ROOT not in file_path.parents and file_path != ROOT:
            self._send(403, b"Forbidden", "text/plain; charset=utf-8")
            return
        if file_path.name in PROTECTED_STATIC_NAMES:
            self._send(403, b"Forbidden", "text/plain; charset=utf-8")
            return
        if not file_path.is_file():
            self._send(404, b"Not found", "text/plain; charset=utf-8")
            return

        content_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        if content_type.startswith("text/"):
            content_type += "; charset=utf-8"
        self._send(200, file_path.read_bytes(), content_type)

    def _leaker_proxy(self, parsed: urllib.parse.SplitResult) -> None:
        try:
            upstream_path = leaker_upstream_path(parsed.path)
            upstream_url = f"{LEAKER_SITE_BASE_URL}{upstream_path}"
            if parsed.query:
                upstream_url = f"{upstream_url}?{parsed.query}"

            body = None
            if self.command not in {"GET", "HEAD"}:
                length = int(self.headers.get("Content-Length", "0"))
                if length > MAX_BODY_BYTES * 8:
                    raise ValueError("Request body is too large.")
                body = self.rfile.read(length) if length else b""

            blocked_request_headers = {
                "host",
                "connection",
                "content-length",
                "accept-encoding",
                "cookie",
            }
            headers = {
                key: value
                for key, value in self.headers.items()
                if key.lower() not in blocked_request_headers
            }
            headers["Host"] = "6ureleaks.com"
            headers["User-Agent"] = LEAKER_PROXY_USER_AGENT
            headers.setdefault("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            if self.command not in {"GET", "HEAD"}:
                headers["Origin"] = LEAKER_SITE_BASE_URL
            headers["Referer"] = LEAKER_SITE_BASE_URL + "/dashboard"

            with LEAKER_PROXY_LOCK:
                response = LEAKER_PROXY_SESSION.request(
                    self.command,
                    upstream_url,
                    headers=headers,
                    data=body,
                    allow_redirects=False,
                    timeout=LEAKER_PROXY_TIMEOUT_SECONDS,
                )
                try:
                    LEAKER_PROXY_SESSION.cookies.save(ignore_discard=True, ignore_expires=True)
                except Exception:
                    pass

            content_type = response.headers.get("Content-Type", "application/octet-stream")
            response_body = b"" if self.command == "HEAD" else response.content
            if response_body and should_rewrite_leaker_content(content_type) and should_rewrite_leaker_page(content_type, upstream_path):
                text = response.text
                text = rewrite_leaker_proxy_text(text)
                text = inject_leaker_discord_oauth_bridge(text)
                response_body = text.encode(response.encoding or "utf-8", errors="replace")

            blocked_response_headers = {
                "content-security-policy",
                "content-security-policy-report-only",
                "x-frame-options",
                "content-encoding",
                "content-length",
                "transfer-encoding",
                "connection",
                "set-cookie",
                "strict-transport-security",
                "cross-origin-opener-policy",
                "cross-origin-embedder-policy",
                "cross-origin-resource-policy",
            }
            extra_headers: dict[str, str] = {}
            for key, value in response.headers.items():
                lower = key.lower()
                if lower in blocked_response_headers or lower == "content-type":
                    continue
                if lower == "location":
                    if is_discord_oauth_url(value) and self.command != "HEAD":
                        body = leaker_discord_oauth_bridge_html(value).encode("utf-8")
                        self._send(
                            200,
                            body,
                            "text/html; charset=utf-8",
                            {"X-6ure-Leaker-Proxy": "1", "X-6ure-Leaker-OAuth-Bridge": "1"},
                        )
                        return
                    extra_headers[key] = leaker_proxy_location(value)
                else:
                    extra_headers[key] = value
            extra_headers["X-6ure-Leaker-Proxy"] = "1"
            self._send(response.status_code, response_body, content_type, extra_headers)
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            return
        except Exception as error:
            self._send_json(502, {"success": False, "msg": f"Leaker proxy failed: {error}"})

    def _window_action(self) -> None:
        try:
            payload = self._read_json()
            action = str(payload.get("action", "")).strip().lower()
            if action not in {"minimize", "maximize", "close"}:
                raise ValueError("Unsupported window action.")

            bridge = getattr(self.server, "window_bridge", None)
            if bridge is None:
                raise ValueError("Window bridge is unavailable.")

            threading.Thread(target=bridge.window_action, args=(action,), daemon=True).start()
            if action == "close":
                threading.Thread(target=self._force_exit_after_close, daemon=True).start()
            self._send_json(200, {"success": True})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    @staticmethod
    def _force_exit_after_close() -> None:
        time.sleep(1.2)
        stop_discord_presence()
        os._exit(0)

    def _open_url(self) -> None:
        try:
            payload = self._read_json()
            url = str(payload.get("url", "")).strip()
            parsed = urllib.parse.urlsplit(url)
            if parsed.scheme != "https" or parsed.netloc.lower() not in ALLOWED_EXTERNAL_HOSTS:
                raise ValueError("URL is not allowed.")
            webbrowser.open(url)
            self._send_json(200, {"success": True})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _leaker_bridge(self):
        bridge = getattr(self.server, "window_bridge", None)
        if bridge is None:
            raise ValueError("Window bridge is unavailable.")
        return bridge

    def _leaker_mode_status(self) -> None:
        try:
            self._send_json(200, self._leaker_bridge().leaker_status())
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _leaker_mode_start(self) -> None:
        try:
            self._send_json(200, self._leaker_bridge().start_leaker_mode())
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _leaker_mode_launch(self) -> None:
        try:
            self._send_json(200, self._leaker_bridge().launch_leaker_mode())
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _leaker_mode_exit(self) -> None:
        try:
            self._send_json(200, self._leaker_bridge().exit_leaker_mode())
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _leaker_oauth_status(self) -> None:
        try:
            self._send_json(200, self._leaker_bridge().leaker_oauth_status())
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _leaker_oauth_bridge(self, query: str) -> None:
        try:
            params = urllib.parse.parse_qs(query or "", keep_blank_values=True)
            url = normalize_discord_oauth_url((params.get("url") or [""])[0])
            if not is_discord_oauth_url(url):
                raise ValueError("Invalid Discord OAuth URL.")
            body = leaker_discord_oauth_bridge_html(url).encode("utf-8")
            self._send(
                200,
                body,
                "text/html; charset=utf-8",
                {"X-6ure-Leaker-OAuth-Bridge": "1"},
            )
        except Exception as error:
            clean_error = html.escape(str(error))
            self._send(
                400,
                f"Discord OAuth bridge failed: {clean_error}".encode("utf-8"),
                "text/plain; charset=utf-8",
            )

    def _leaker_oauth_open(self) -> None:
        try:
            payload = self._read_json()
            url = str(payload.get("url", "") or "").strip()
            self._send_json(200, self._leaker_bridge().open_leaker_oauth(url))
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _discord_presence_status(self) -> None:
        try:
            payload = get_discord_presence_status()
            payload["success"] = True
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _network_status(self) -> None:
        try:
            payload = get_network_status()
            payload["success"] = True
            payload["checkedAt"] = int(time.time() * 1000)
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _discord_presence_activity(self) -> None:
        try:
            payload = self._read_json()
            result = set_discord_presence_activity(
                details=str(payload.get("details", "") or "") if "details" in payload else None,
                state=str(payload.get("state", "") or "") if "state" in payload else None,
                small_image=str(payload.get("smallImage", "") or "") if "smallImage" in payload else None,
                small_text=str(payload.get("smallText", "") or "") if "smallText" in payload else None,
            )
            result["success"] = True
            self._send_json(200, result)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _discord_presence_clear(self) -> None:
        try:
            manager = start_discord_presence()
            payload = manager.clear()
            payload["success"] = True
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_last(self) -> None:
        state = get_files_state()
        session = get_session_snapshot()
        authenticated = bool(session["authenticated"])
        last_folder_paths = normalize_string_list(state.get("lastFolderPaths"))
        last_folder_names = normalize_string_list(state.get("lastFolderNames"))
        if not last_folder_paths and state.get("lastFolderPath"):
            last_folder_paths = [str(state.get("lastFolderPath", "")).strip()]
        if not last_folder_names and state.get("lastFolderName"):
            last_folder_names = [str(state.get("lastFolderName", "")).strip()]
        self._send_json(
            200,
            {
                "success": True,
                "lastEditor": state.get("lastEditor", ""),
                "lastFolderPath": state.get("lastFolderPath", ""),
                "lastFolderName": state.get("lastFolderName", ""),
                "lastFolderPaths": last_folder_paths,
                "lastFolderNames": last_folder_names,
                "authenticated": authenticated,
                "hasCredentials": authenticated,
                "filesUsername": session["username"],
                "storagePath": str(DATA_ROOT),
            },
        )

    def _files_login(self) -> None:
        try:
            payload = self._read_json()
            username = str(payload.get("username", "")).strip()
            password = str(payload.get("password", ""))
            validate_files_credentials(username, password)
            persisted = save_files_state(username=username, password=password)
            set_session_credentials(username, password)
            sync_session_from_state(persisted)
            set_discord_presence_activity(details="Managing 6ure Files", state="Ready to upload")
            self._send_json(200, {"success": True, "username": username})
        except PermissionError as error:
            clear_session_credentials()
            self._send_json(401, {"success": False, "msg": str(error)})
        except Exception as error:
            clear_session_credentials()
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_logout(self) -> None:
        try:
            clear_session_credentials()
            clear_persisted_account_data()
            set_discord_presence_activity(details="6ure Files", state="Waiting for sign in")
            self._send_json(200, {"success": True})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_status(self, query: str) -> None:
        try:
            params = urllib.parse.parse_qs(query)
            job_id = str(params.get("id", [""])[0])
            with FILES_JOBS_LOCK:
                job = FILES_JOBS.get(job_id)
            if not job:
                raise ValueError("Upload job was not found.")
            payload = job.snapshot()
            payload["success"] = True
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_select_folder(self) -> None:
        try:
            payload = self._read_json()
            existing_folder_paths = payload.get("existingFolderPaths")
            if not isinstance(existing_folder_paths, list):
                existing_folder_paths = []

            bridge = getattr(self.server, "window_bridge", None)
            if bridge is None:
                raise ValueError("Window bridge is unavailable.")

            folder_paths = bridge.select_folders()
            if not folder_paths:
                self._send_json(200, {"success": False, "cancelled": True})
                return

            paths = normalize_local_folder_paths([*existing_folder_paths, *folder_paths])
            folder_payload = [get_local_folder_summary(path) for path in paths]
            save_last_folder_selection(paths)
            self._send_json(
                200,
                {
                    "success": True,
                    "path": folder_payload[0]["path"],
                    "name": folder_payload[0]["name"],
                    "folders": folder_payload,
                },
            )
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_folder_summary(self) -> None:
        try:
            payload = self._read_json()
            folder_paths = payload.get("folderPaths")
            if not isinstance(folder_paths, list):
                folder_paths = [str(payload.get("folderPath", "")).strip()]
            folder_payload = get_local_folder_summaries(folder_paths)
            save_last_folder_selection([Path(item["path"]).expanduser().resolve() for item in folder_payload])
            self._send_json(200, {"success": True, "folders": folder_payload})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _protected_list(self) -> None:
        try:
            payload = get_protected_list_payload()
            payload["success"] = True
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _protected_check(self) -> None:
        try:
            payload = self._read_json()
            names = payload.get("names")
            if not isinstance(names, list):
                names = [payload.get("name", "")]
            result = check_protected_names([str(name or "") for name in names])
            result["success"] = True
            self._send_json(200, result)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_start_upload(self) -> None:
        try:
            payload = self._read_json()
            editor_name = str(payload.get("editorName", "")).strip()
            raw_folder_paths = payload.get("folderPaths")
            if isinstance(raw_folder_paths, list):
                folder_paths = raw_folder_paths
            else:
                folder_paths = [str(payload.get("folderPath", "")).strip()]
            job = start_files_job(editor_name, folder_paths)
            save_files_state(
                lastEditor=job.editor_name,
                lastFolderPath=str(job.folder_path),
                lastFolderName=job.folder_name,
                lastFolderPaths=[str(path) for path in job.folder_paths],
                lastFolderNames=list(job.folder_names),
            )
            self._send_json(200, {"success": True, "jobId": job.id})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _files_cancel_upload(self) -> None:
        try:
            payload = self._read_json()
            job_id = str(payload.get("jobId", "")).strip()
            with FILES_JOBS_LOCK:
                job = FILES_JOBS.get(job_id)
            if not job:
                raise ValueError("Upload job was not found.")
            job.request_cancel()
            snapshot = job.snapshot()
            snapshot["success"] = True
            self._send_json(200, snapshot)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _cloud_list(self, query: str) -> None:
        try:
            params = urllib.parse.parse_qs(query)
            cloud_path = normalize_remote_path(params.get("path", ["/"])[0])
            client = get_authenticated_remote_client()
            entries = client.list_dir(cloud_path)
            self._send_json(
                200,
                {
                    "success": True,
                    "path": cloud_path,
                    "parentPath": remote_parent_path(cloud_path) if cloud_path != "/" else "",
                    "breadcrumbs": remote_breadcrumbs(cloud_path),
                    "entries": entries,
                },
            )
        except PermissionError as error:
            clear_session_credentials()
            self._send_json(401, {"success": False, "msg": str(error)})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _cloud_action(self) -> None:
        try:
            payload = self._read_json()
            action = str(payload.get("action", "") or "").strip().lower()
            source_path = normalize_remote_path(str(payload.get("path", "") or ""), allow_root=False)
            item_type = str(payload.get("type", "") or "").strip().lower()
            source_name = remote_basename(source_path)
            source_parent = remote_parent_path(source_path)
            client = get_authenticated_remote_client()

            if action == "rename":
                new_name = normalize_remote_name(str(payload.get("name", "") or ""), "New name")
                target_path = remote_join(source_parent, new_name)
                client.move(source_path, target_path)
                self._send_json(
                    200,
                    {
                        "success": True,
                        "msg": f"Renamed to {new_name}.",
                        "path": target_path,
                        "listPath": remote_parent_path(target_path),
                    },
                )
                return

            if action == "move":
                destination_folder = normalize_remote_path(
                    str(payload.get("destinationPath", "") or ""),
                    "Destination folder",
                )
                target_path = remote_join(destination_folder, source_name)
                client.move(source_path, target_path)
                self._send_json(
                    200,
                    {
                        "success": True,
                        "msg": f"Moved to {destination_folder}.",
                        "path": target_path,
                        "listPath": remote_parent_path(target_path),
                    },
                )
                return

            if action == "delete":
                client.delete(source_path, item_type)
                self._send_json(
                    200,
                    {
                        "success": True,
                        "msg": f"Deleted {source_name}.",
                        "listPath": source_parent,
                    },
                )
                return

            if action == "extract":
                target_path = str(payload.get("targetPath", "") or "").strip()
                result = client.extract_remote_zip(source_path, target_path)
                self._send_json(
                    200,
                    {
                        "success": True,
                        "msg": f"Extracted {source_name}.",
                        "result": result,
                        "path": result["path"],
                        "listPath": remote_parent_path(result["path"]),
                    },
                )
                return

            raise ValueError("Unsupported cloud action.")
        except PermissionError as error:
            clear_session_credentials()
            self._send_json(401, {"success": False, "msg": str(error)})
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _update_status(self) -> None:
        try:
            payload = get_update_status()
            payload["success"] = True
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _update_check(self) -> None:
        try:
            payload = check_for_update()
            payload["success"] = True
            self._send_json(200, payload)
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _update_install(self) -> None:
        try:
            payload = prepare_update_install()
            payload["success"] = True
            payload["restarting"] = True
            self._send_json(200, payload)
            threading.Thread(target=self._close_for_update, daemon=True).start()
        except Exception as error:
            self._send_json(400, {"success": False, "msg": str(error)})

    def _close_for_update(self) -> None:
        time.sleep(0.8)
        bridge = getattr(self.server, "window_bridge", None)
        if bridge is not None:
            try:
                bridge.window_action("close")
            except Exception:
                pass
        time.sleep(1.4)
        stop_discord_presence()
        os._exit(0)

    def log_message(self, format: str, *args) -> None:
        print(f"[{self.log_date_time_string()}] {format % args}")


def create_server(port: int = PORT) -> ThreadingHTTPServer:
    return ThreadingHTTPServer(("127.0.0.1", port), FilesAppHandler)


def main() -> None:
    boot_state = clear_last_files_selection()
    sync_session_from_state(boot_state)
    server = create_server(PORT)
    print(f"6ure Files local server running at http://localhost:{PORT}")
    server.serve_forever()


BOOT_STATE = clear_last_files_selection()
sync_session_from_state(BOOT_STATE)
refresh_discord_presence_from_session()


if __name__ == "__main__":
    main()
